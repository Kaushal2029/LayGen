import { NextRequest, NextResponse } from 'next/server';
import { createAIService } from '@/utils/ai';
import { ApiResponse } from '@/types';

export async function POST(request: NextRequest) {
  console.log('🎨 [DESIGN API] Starting design generation process...');
  const startTime = Date.now();
  
  try {
    console.log('📥 [DESIGN API] Extracting request data...');
    const { prompt, dataAnalysis } = await request.json();
    
    console.log('📋 [DESIGN API] Request data:', {
      hasPrompt: !!prompt,
      hasDataAnalysis: !!dataAnalysis,
      promptLength: prompt?.length || 0
    });
    
    if (!prompt && !dataAnalysis) {
      console.log('❌ [DESIGN API] No prompt or data analysis provided');
      return NextResponse.json<ApiResponse<null>>({
        success: false,
        error: 'Prompt or data analysis is required'
      }, { status: 400 });
    }

    console.log('🤖 [DESIGN API] Creating AI service for design generation...');
    const aiService = createAIService();
    console.log('✅ [DESIGN API] AI service created successfully');

    // Use only the provided prompt, no hardcoded suggestions
    const designPrompt = prompt || 'Create a modern web application';
    
    // Create a mock Excel data structure to trigger the design generation logic
    const mockExcelData = {
      type: 'excel_data',
      fileName: 'design-requirements.xlsx',
      fileSize: 1024,
      fileType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      description: designPrompt,
      projectName: 'Design Requirements'
    };
    
    const testDocument = {
      id: 'design-gen-doc',
      name: 'design-requirements.xlsx',
      type: 'xlsx' as const,
      size: 1024,
      content: JSON.stringify(mockExcelData),
      uploadedAt: new Date()
    };

    // Process with AI to generate design options
    console.log('🧠 [DESIGN API] Processing with AI service...');
    const result = await aiService.parseDocument(testDocument);

    if (!result.success) {
      console.log('❌ [DESIGN API] AI processing failed:', result.error);
      return NextResponse.json<ApiResponse<null>>({
        success: false,
        error: result.error
      }, { status: 500 });
    }

    console.log('✅ [DESIGN API] AI processing successful');
    
    // Extract design options from the result
    const designData = result.layoutData as any; // eslint-disable-line @typescript-eslint/no-explicit-any
    const designOptions = designData.designOptions || [];
    const colorCombinations = designData.colorCombinations || [];

    console.log('📊 [DESIGN API] Generated data:', {
      designOptionsCount: designOptions.length,
      colorCombinationsCount: colorCombinations.length
    });

    const processingTime = Date.now() - startTime;
    console.log(`⏱️ [DESIGN API] Total processing time: ${processingTime}ms`);

    return NextResponse.json<ApiResponse<{
      designOptions: any[]; // eslint-disable-line @typescript-eslint/no-explicit-any
      colorCombinations: any[]; // eslint-disable-line @typescript-eslint/no-explicit-any
      dataAnalysis: any; // eslint-disable-line @typescript-eslint/no-explicit-any
    }>>({
      success: true,
      data: {
        designOptions,
        colorCombinations,
        dataAnalysis: dataAnalysis || designData.dataAnalysis
      },
      message: 'Design options generated successfully'
    });

  } catch (error: any) { // eslint-disable-line @typescript-eslint/no-explicit-any
    console.error('❌ [DESIGN API] Design generation failed:', error);
    const processingTime = Date.now() - startTime;
    
    return NextResponse.json<ApiResponse<null>>({
      success: false,
      error: error.message || 'Failed to generate design options',
      message: `Design generation failed after ${processingTime}ms`
    }, { status: 500 });
  }
}