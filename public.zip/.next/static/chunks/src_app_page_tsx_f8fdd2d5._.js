(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_768e0ee6._.js",
  "static/chunks/node_modules_xlsx_xlsx_mjs_fef98e92._.js",
  "static/chunks/node_modules_16df996a._.js"
],
    source: "dynamic"
});
