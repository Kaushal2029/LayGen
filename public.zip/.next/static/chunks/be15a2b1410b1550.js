__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/113ae4dc14b224ae.js",
  "static/chunks/turbopack-f3dcab94421429bb.js"
])
