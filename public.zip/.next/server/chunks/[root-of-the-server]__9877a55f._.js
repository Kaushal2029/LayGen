module.exports = [
"[project]/.next-internal/server/app/api/figma/generate-designs/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/src/utils/gemini-ai.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GeminiAIService",
    ()=>GeminiAIService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$google$2f$generative$2d$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@google/generative-ai/dist/index.mjs [app-route] (ecmascript)");
;
class GeminiAIService {
    genAI;
    model;
    constructor(apiKey){
        this.genAI = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$google$2f$generative$2d$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GoogleGenerativeAI"](apiKey);
        this.model = this.genAI.getGenerativeModel({
            model: 'gemini-1.5-flash'
        });
    }
    async parseDocument(document) {
        try {
            // Check if this is Excel data
            let isExcelData = false;
            try {
                const parsedContent = JSON.parse(document.content);
                isExcelData = parsedContent.type === 'excel_data';
            } catch  {
            // Not JSON, continue with normal parsing
            }
            let prompt;
            if (isExcelData) {
                // Simple Excel file analysis - just use file info, no complex parsing
                const fileInfo = JSON.parse(document.content);
                prompt = `
          Create a web application based on this Excel file description. The user wants to build a data management application.
          
          File Information:
          - File Name: ${fileInfo.fileName}
          - File Size: ${fileInfo.fileSize} bytes
          - File Type: ${fileInfo.fileType}
          
          Generate a complete application design with the following structure:
          {
            "dataAnalysis": {
              "dataType": "Data Management Application",
              "columns": ["Title", "Description", "Type", "Priority", "Status"],
              "recordCount": "Multiple records",
              "dataPatterns": "Structured data with title, description, type, priority, and status fields",
              "suggestedAppType": "Task/Project Management Dashboard",
              "projectName": "${fileInfo.fileName.replace(/\.(xlsx|xls)$/i, '')}",
              "titleColumn": "Title"
            },
            "designOptions": [
              {
                "id": "dashboard_1",
                "name": "Modern Dashboard",
                "description": "Clean dashboard with cards and filters",
                "preview": "Modern card-based layout with search and filter options",
                "components": [
                  {
                    "name": "Header",
                    "type": "header",
                    "description": "Application header with title and search",
                    "properties": {
                      "title": "Project Management",
                      "showSearch": true
                    },
                    "layout": {
                      "x": 0,
                      "y": 0,
                      "width": 1200,
                      "height": 80
                    }
                  },
                  {
                    "name": "FilterBar",
                    "type": "filter",
                    "description": "Filter controls for type and priority",
                    "properties": {
                      "filters": ["Type", "Priority", "Status"]
                    },
                    "layout": {
                      "x": 0,
                      "y": 80,
                      "width": 1200,
                      "height": 60
                    }
                  },
                  {
                    "name": "DataGrid",
                    "type": "table",
                    "description": "Main data display table",
                    "properties": {
                      "columns": ["Title", "Description", "Type", "Priority", "Status", "Actions"],
                      "sortable": true,
                      "editable": true
                    },
                    "layout": {
                      "x": 0,
                      "y": 140,
                      "width": 1200,
                      "height": 400
                    }
                  }
                ],
                "layout": {
                  "type": "dashboard",
                  "theme": "light",
                  "colors": {
                    "primary": "#3B82F6",
                    "secondary": "#6B7280",
                    "background": "#FFFFFF",
                    "text": "#111827"
                  }
                }
              },
              {
                "id": "card_2",
                "name": "Card Layout",
                "description": "Card-based layout for better visual appeal",
                "preview": "Grid of cards showing each data item",
                "components": [
                  {
                    "name": "CardGrid",
                    "type": "grid",
                    "description": "Grid of data cards",
                    "properties": {
                      "columns": 3,
                      "cardType": "data"
                    },
                    "layout": {
                      "x": 0,
                      "y": 0,
                      "width": 1200,
                      "height": 600
                    }
                  }
                ],
                "layout": {
                  "type": "grid",
                  "theme": "light",
                  "colors": {
                    "primary": "#10B981",
                    "secondary": "#6B7280",
                    "background": "#F9FAFB",
                    "text": "#111827"
                  }
                }
              }
            ],
            "requirements": "Create a responsive web application for managing structured data with CRUD operations, filtering, and search functionality"
          }
        `;
            } else {
                // Normal document parsing
                prompt = `
          Analyze the following document and extract design requirements. 
          Return a JSON object with the following structure:
          {
            "components": [
              {
                "name": "Component Name",
                "type": "button|input|card|header|footer|etc",
                "description": "What this component does",
                "properties": {
                  "text": "Button text",
                  "color": "primary|secondary|etc",
                  "size": "small|medium|large",
                  "position": "top|center|bottom|left|right"
                },
                "layout": {
                  "x": 0,
                  "y": 0,
                  "width": 200,
                  "height": 50
                }
              }
            ],
            "layout": {
              "type": "single-page|multi-page|dashboard|landing",
              "theme": "light|dark|auto",
              "colors": {
                "primary": "#3B82F6",
                "secondary": "#6B7280",
                "background": "#FFFFFF",
                "text": "#111827"
              },
              "typography": {
                "heading": "Inter Bold",
                "body": "Inter Regular",
                "sizes": {
                  "h1": 32,
                  "h2": 24,
                  "h3": 20,
                  "body": 16,
                  "small": 14
                }
              },
              "spacing": {
                "xs": 4,
                "sm": 8,
                "md": 16,
                "lg": 24,
                "xl": 32
              }
            },
            "requirements": "Summary of key requirements"
          }

          Document content:
          ${document.content}
        `;
            }
            const systemMessage = 'You are a design system expert. Analyze documents and extract structured design requirements. Always return valid JSON.';
            const fullPrompt = `${systemMessage}\n\n${prompt}`;
            const result = await this.model.generateContent(fullPrompt);
            const response = await result.response;
            const content = response.text();
            if (!content) {
                throw new Error('No response from Gemini');
            }
            // Clean the response to extract JSON from markdown if present
            let jsonContent = content.trim();
            // Remove markdown code blocks if present
            if (jsonContent.includes('```json')) {
                const jsonMatch = jsonContent.match(/```json\s*([\s\S]*?)\s*```/);
                if (jsonMatch) {
                    jsonContent = jsonMatch[1].trim();
                }
            } else if (jsonContent.includes('```')) {
                const jsonMatch = jsonContent.match(/```\s*([\s\S]*?)\s*```/);
                if (jsonMatch) {
                    jsonContent = jsonMatch[1].trim();
                }
            }
            // Try to find JSON object in the response
            const jsonStart = jsonContent.indexOf('{');
            const jsonEnd = jsonContent.lastIndexOf('}');
            if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
                jsonContent = jsonContent.substring(jsonStart, jsonEnd + 1);
            }
            // Clean up common JSON issues
            jsonContent = jsonContent.replace(/\/\/.*$/gm, '') // Remove single-line comments
            .replace(/\/\*[\s\S]*?\*\//g, '') // Remove multi-line comments
            .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
            .replace(/([{,]\s*)(\w+):/g, '$1"$2":') // Add quotes to unquoted keys
            .replace(/:\s*'([^']*)'/g, ': "$1"') // Replace single quotes with double quotes
            .replace(/:\s*([^",{\[\s][^,}\]]*?)(\s*[,}])/g, (match, value, ending)=>{
                // Only quote if it's not already a number, boolean, or quoted
                const trimmedValue = value.trim();
                if (!/^[\d\-\.]+$/.test(trimmedValue) && !/^(true|false|null)$/.test(trimmedValue) && !trimmedValue.startsWith('"')) {
                    return `: "${trimmedValue}"${ending}`;
                }
                return match;
            }).replace(/"\s*:\s*"([^"]*)"\s*"/g, '": "$1"') // Fix double-quoted values
            .replace(/\s+/g, ' ') // Normalize whitespace
            .trim();
            console.log('Cleaned JSON content:', jsonContent.substring(0, 500) + '...');
            let parsedData;
            try {
                parsedData = JSON.parse(jsonContent);
            } catch (parseError) {
                console.error('❌ [GEMINI] JSON parse error:', parseError);
                console.error('Problematic JSON:', jsonContent);
                // Try to fix common issues and parse again
                try {
                    // More aggressive cleaning
                    jsonContent = jsonContent.replace(/\/\/.*$/gm, '') // Remove single-line comments
                    .replace(/\/\*[\s\S]*?\*\//g, '') // Remove multi-line comments
                    .replace(/([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:/g, '$1"$2":') // Ensure all keys are quoted
                    .replace(/:\s*([^",{\[\s][^,}\]]*?)(\s*[,}])/g, (match, value, ending)=>{
                        // Only quote if it's not already a number, boolean, or quoted
                        const trimmedValue = value.trim();
                        if (!/^[\d\-\.]+$/.test(trimmedValue) && !/^(true|false|null)$/.test(trimmedValue) && !trimmedValue.startsWith('"')) {
                            return `: "${trimmedValue}"${ending}`;
                        }
                        return match;
                    }).replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
                    .replace(/([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:/g, '$1"$2":') // Re-quote keys after comma removal
                    .replace(/:\s*"([^"]*)"\s*([,}])/g, ': "$1"$2') // Ensure proper spacing around quoted values
                    .replace(/\s+/g, ' ') // Normalize whitespace
                    .trim();
                    console.log('Retry with cleaned JSON:', jsonContent.substring(0, 500) + '...');
                    parsedData = JSON.parse(jsonContent);
                } catch (secondError) {
                    console.error('Second JSON parse error:', secondError);
                    console.error('Problematic JSON at position 374:', jsonContent.substring(350, 400));
                    // Final attempt: Try to extract just the essential parts
                    try {
                        // Try to extract designOptions with better regex
                        const designOptionsMatch = jsonContent.match(/"designOptions"\s*:\s*\[([\s\S]*?)\](?=\s*[,}])/);
                        if (designOptionsMatch) {
                            let designOptionsContent = designOptionsMatch[1];
                            // Clean the extracted content
                            designOptionsContent = designOptionsContent.replace(/\/\/.*$/gm, '') // Remove comments
                            .replace(/\/\*[\s\S]*?\*\//g, '') // Remove multi-line comments
                            .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
                            .replace(/([{,]\s*)(\w+):/g, '$1"$2":') // Quote unquoted keys
                            .replace(/:\s*'([^']*)'/g, ': "$1"') // Replace single quotes
                            .replace(/:\s*([^",{\[\s][^,}\]]*?)(\s*[,}])/g, (match, value, ending)=>{
                                const trimmedValue = value.trim();
                                if (!/^[\d\-\.]+$/.test(trimmedValue) && !/^(true|false|null)$/.test(trimmedValue) && !trimmedValue.startsWith('"')) {
                                    return `: "${trimmedValue}"${ending}`;
                                }
                                return match;
                            }).replace(/\s+/g, ' ').trim();
                            const designOptionsJson = `{"designOptions": [${designOptionsContent}]}`;
                            console.log('Extracting designOptions only:', designOptionsJson.substring(0, 200) + '...');
                            parsedData = JSON.parse(designOptionsJson);
                        } else {
                            throw new Error('Could not extract designOptions from malformed JSON');
                        }
                    } catch (finalError) {
                        console.error('Final JSON parse error:', finalError);
                        // Return a minimal valid response instead of throwing
                        parsedData = {
                            designOptions: [
                                {
                                    id: 'fallback-1',
                                    name: 'Modern Design',
                                    description: 'Clean and modern interface',
                                    preview: 'Responsive layout with modern components',
                                    components: [
                                        {
                                            name: 'Header',
                                            type: 'header',
                                            description: 'Top navigation',
                                            properties: {
                                                title: 'App'
                                            },
                                            layout: {
                                                x: 0,
                                                y: 0,
                                                width: 1200,
                                                height: 80
                                            }
                                        }
                                    ],
                                    layout: {
                                        type: 'dashboard',
                                        theme: 'light',
                                        colors: {
                                            primary: '#3B82F6',
                                            secondary: '#6B7280',
                                            background: '#FFFFFF',
                                            text: '#111827'
                                        }
                                    }
                                }
                            ]
                        };
                        console.log('Using fallback design due to JSON parsing failure');
                    }
                }
            }
            // Check if this is a design options request (has designOptions array)
            if (parsedData.designOptions && Array.isArray(parsedData.designOptions)) {
                // Return the data as-is for design options
                return {
                    success: true,
                    layoutData: parsedData,
                    confidence: 0.85,
                    suggestions: [
                        'Consider adding hover states for interactive elements',
                        'Ensure proper contrast ratios for accessibility',
                        'Add responsive breakpoints for mobile devices'
                    ]
                };
            }
            // Otherwise, convert to standard layout data
            const layoutData = this.convertToLayoutData(parsedData);
            return {
                success: true,
                layoutData,
                confidence: 0.85,
                suggestions: [
                    'Consider adding hover states for interactive elements',
                    'Ensure proper contrast ratios for accessibility',
                    'Add responsive breakpoints for mobile devices'
                ]
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Failed to parse document',
                confidence: 0
            };
        }
    }
    async generateLayoutVariations(baseLayout, count = 2) {
        try {
            const prompt = `
        Based on this existing layout, generate ${count} alternative variations that maintain the same functionality but with different visual arrangements.
        
        Current layout:
        ${JSON.stringify(baseLayout, null, 2)}
        
        Return a JSON array with ${count} layout variations, each following the same structure as the input layout.
        Focus on:
        - Different component arrangements
        - Alternative color schemes
        - Varied spacing and sizing
        - Different visual hierarchy
        - Maintain accessibility and usability
      `;
            const systemMessage = 'You are a UI/UX designer. Generate creative layout variations while maintaining functionality and usability. Always return valid JSON arrays.';
            const fullPrompt = `${systemMessage}\n\n${prompt}`;
            const result = await this.model.generateContent(fullPrompt);
            const response = await result.response;
            const content = response.text();
            if (!content) {
                throw new Error('No response from Gemini');
            }
            // Clean the response to extract JSON from markdown if present
            let jsonContent = content.trim();
            // Remove markdown code blocks if present
            if (jsonContent.includes('```json')) {
                const jsonMatch = jsonContent.match(/```json\s*([\s\S]*?)\s*```/);
                if (jsonMatch) {
                    jsonContent = jsonMatch[1].trim();
                }
            } else if (jsonContent.includes('```')) {
                const jsonMatch = jsonContent.match(/```\s*([\s\S]*?)\s*```/);
                if (jsonMatch) {
                    jsonContent = jsonMatch[1].trim();
                }
            }
            // Try to find JSON array in the response
            const jsonStart = jsonContent.indexOf('[');
            const jsonEnd = jsonContent.lastIndexOf(']');
            if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
                jsonContent = jsonContent.substring(jsonStart, jsonEnd + 1);
            }
            const variations = JSON.parse(jsonContent);
            return {
                success: true,
                layoutData: variations[0],
                confidence: 0.8,
                suggestions: [
                    'Try different color combinations',
                    'Experiment with component positioning',
                    'Consider alternative typography scales'
                ]
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Failed to generate variations',
                confidence: 0
            };
        }
    }
    async generateImage(prompt) {
        try {
            console.log('Generating image with Gemini with prompt:', prompt.substring(0, 100) + '...');
            // Note: Gemini doesn't have image generation like DALL-E
            // We'll return a placeholder response indicating this limitation
            return {
                success: false,
                error: 'Image generation is not available with Gemini. Please use OpenAI for image generation.',
                confidence: 0
            };
        } catch (error) {
            console.error('Image generation error:', error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Failed to generate image',
                confidence: 0
            };
        }
    }
    async generateCode(layoutData, framework = 'html') {
        const maxRetries = 5; // Increased retries
        const retryDelay = 3000; // Increased delay to 3 seconds
        for(let attempt = 1; attempt <= maxRetries; attempt++){
            try {
                console.log(`🔄 [GEMINI] Code generation attempt ${attempt}/${maxRetries}`);
                console.log(`⏰ [GEMINI] Attempt started at: ${new Date().toISOString()}`);
                // Extract project info from layout data
                const projectName = layoutData.dataAnalysis?.projectName || 'Generated App';
                const selectedColors = layoutData.selectedColors || {};
                const description = layoutData.dataAnalysis?.description || 'A modern web application';
                const prompt = `You are an expert full-stack developer. Create a COMPLETE, PRODUCTION-READY web application for: ${projectName}

Project Description: ${description}

REQUIREMENTS:
1. HTML: Create a comprehensive HTML page with modern structure, semantic elements, forms, navigation, and interactive components
2. CSS: Write modern, responsive CSS with advanced styling, animations, transitions, and mobile-first design
3. JavaScript: Build complete functionality with data management, user interactions, form handling, dynamic content, and modern ES6+ features
4. Colors: Use these colors: ${JSON.stringify(selectedColors)}
5. Features: Include search, filtering, CRUD operations, data validation, error handling, loading states, and user feedback
6. Responsive: Mobile-first design that works perfectly on all screen sizes
7. Modern: Use latest web standards, CSS Grid/Flexbox, smooth animations, and professional UI/UX
8. Professional: Clean, well-structured code with proper comments and error handling

APPLICATION STRUCTURE:
- Modern header with navigation and branding
- Main content area with data visualization and management
- Interactive forms for adding/editing data
- Advanced search and filter functionality
- Data tables with sorting and pagination
- Modal dialogs and popups for interactions
- Footer with additional information
- Responsive sidebar navigation
- Loading states and smooth animations
- Comprehensive error handling and user feedback
- Data persistence and state management

Make it a REAL, COMPLETE, PRODUCTION-READY application with substantial functionality and modern design patterns.

Return ONLY valid JSON with this EXACT structure:
{
  "html": "complete HTML content for index.html",
  "css": "complete CSS content for styles.css", 
  "javascript": "complete JavaScript content for script.js",
  "readme": "complete README content explaining the application purpose and usage"
}`;
                const systemMessage = `You are an expert full-stack developer with extensive experience. Create COMPLETE, PRODUCTION-READY web applications with comprehensive functionality and modern design.

REQUIREMENTS:
- Generate FULL, functional applications with substantial code
- Create comprehensive HTML with modern structure and semantic elements
- Write advanced CSS with responsive design, animations, and modern styling
- Build complete JavaScript with data management, interactions, and modern features
- Include detailed README with clear instructions

QUALITY STANDARDS:
- Professional, clean, well-structured code
- Modern web standards and best practices
- Responsive design that works on all devices
- Comprehensive functionality and user experience
- Proper error handling and validation

You MUST return ONLY valid JSON in the exact format specified. No markdown, no explanations, no code blocks.`;
                const fullPrompt = `${systemMessage}\n\n${prompt}`;
                console.log(`📝 [GEMINI] Sending prompt to Gemini API (attempt ${attempt})...`);
                const result = await this.model.generateContent(fullPrompt);
                const response = await result.response;
                const content = response.text();
                if (!content) {
                    throw new Error('No response from Gemini');
                }
                console.log(`📥 [GEMINI] Received response from Gemini (${content.length} characters)`);
                // Extract JSON from response
                let jsonContent = content.trim();
                console.log(`🔍 [GEMINI] Raw response content (first 500 chars):`, jsonContent.substring(0, 500));
                // Remove markdown code blocks if present
                if (jsonContent.includes('```json')) {
                    const jsonMatch = jsonContent.match(/```json\s*([\s\S]*?)\s*```/);
                    if (jsonMatch) {
                        jsonContent = jsonMatch[1].trim();
                        console.log(`📝 [GEMINI] Extracted JSON from markdown block`);
                    }
                } else if (jsonContent.includes('```')) {
                    const jsonMatch = jsonContent.match(/```\s*([\s\S]*?)\s*```/);
                    if (jsonMatch) {
                        jsonContent = jsonMatch[1].trim();
                        console.log(`📝 [GEMINI] Extracted content from code block`);
                    }
                }
                // Find JSON object boundaries
                const jsonStart = jsonContent.indexOf('{');
                const jsonEnd = jsonContent.lastIndexOf('}');
                if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
                    jsonContent = jsonContent.substring(jsonStart, jsonEnd + 1);
                    console.log(`📝 [GEMINI] Extracted JSON object (${jsonContent.length} chars)`);
                }
                console.log(`🔍 [GEMINI] Final JSON content (first 200 chars):`, jsonContent.substring(0, 200));
                // Parse the JSON
                let codeData;
                try {
                    codeData = JSON.parse(jsonContent);
                    console.log(`✅ [GEMINI] JSON parsed successfully`);
                } catch (parseError) {
                    console.error(`❌ [GEMINI] JSON parse error:`, parseError);
                    console.log(`🔍 [GEMINI] Problematic JSON content:`, jsonContent);
                    // Try to extract individual fields using regex as fallback
                    console.log(`🔄 [GEMINI] Attempting regex extraction as fallback...`);
                    const htmlMatch = jsonContent.match(/"html"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/);
                    const cssMatch = jsonContent.match(/"css"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/);
                    const jsMatch = jsonContent.match(/"javascript"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/);
                    const readmeMatch = jsonContent.match(/"readme"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/);
                    if (htmlMatch || cssMatch || jsMatch || readmeMatch) {
                        console.log(`✅ [GEMINI] Regex extraction successful`);
                        codeData = {
                            html: htmlMatch ? htmlMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"') : '',
                            css: cssMatch ? cssMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"') : '',
                            javascript: jsMatch ? jsMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"') : '',
                            readme: readmeMatch ? readmeMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"') : ''
                        };
                    } else {
                        throw parseError;
                    }
                }
                // Basic validation - just check if we have content
                const htmlLength = codeData.html?.length || 0;
                const cssLength = codeData.css?.length || 0;
                const jsLength = codeData.javascript?.length || 0;
                const readmeLength = codeData.readme?.length || 0;
                console.log(`📊 [GEMINI] Content validation:`, {
                    htmlLength,
                    cssLength,
                    jsLength,
                    readmeLength
                });
                // Only check for completely empty content - no length requirements
                if (htmlLength === 0 || cssLength === 0 || jsLength === 0) {
                    throw new Error('Generated content is empty - missing HTML, CSS, or JavaScript');
                }
                console.log('✅ [GEMINI] Code generation successful on attempt', attempt);
                console.log('🎉 [GEMINI] AI-generated code received successfully!');
                console.log('📊 [GEMINI] Generated code structure:', Object.keys(codeData));
                console.log('📊 [GEMINI] Content lengths:', {
                    html: codeData.html?.length || 0,
                    css: codeData.css?.length || 0,
                    javascript: codeData.javascript?.length || 0,
                    readme: codeData.readme?.length || 0
                });
                return {
                    success: true,
                    layoutData: {
                        html: codeData.html,
                        css: codeData.css,
                        javascript: codeData.javascript,
                        readme: codeData.readme
                    },
                    confidence: 0.9,
                    suggestions: [
                        'Add proper error handling',
                        'Implement loading states',
                        'Add data validation',
                        'Consider performance optimizations'
                    ]
                };
            } catch (error) {
                console.error(`❌ [GEMINI] Code generation attempt ${attempt} failed:`, error);
                console.error(`🔍 [GEMINI] Error details:`, {
                    message: error.message,
                    code: error.code,
                    status: error.status,
                    attempt: attempt,
                    maxRetries: maxRetries
                });
                // Check if it's a retryable error
                const isRetryableError = error.message?.includes('503') || error.message?.includes('overloaded') || error.message?.includes('Service Unavailable') || error.message?.includes('429') || error.message?.includes('rate limit') || error.message?.includes('quota') || error.message?.includes('timeout');
                if (isRetryableError && attempt < maxRetries) {
                    const delay = retryDelay * attempt; // Exponential backoff
                    console.log(`⏳ [GEMINI] Retrying in ${delay}ms... (attempt ${attempt + 1}/${maxRetries})`);
                    console.log(`🔄 [GEMINI] Retry reason: ${error.message}`);
                    await new Promise((resolve)=>setTimeout(resolve, delay));
                    continue;
                }
                // If it's the last attempt, return error (no fallback)
                if (attempt === maxRetries) {
                    console.error('❌ [GEMINI] All code generation attempts failed');
                    console.log('🔍 [GEMINI] Final error details:', {
                        message: error.message,
                        code: error.code,
                        status: error.status,
                        attempts: maxRetries
                    });
                    return {
                        success: false,
                        error: `AI code generation failed after ${maxRetries} attempts: ${error.message || 'Unknown error'}`,
                        confidence: 0
                    };
                }
            }
        }
        // This should never be reached, but just in case
        return {
            success: false,
            error: 'Code generation failed unexpectedly',
            confidence: 0
        };
    }
    convertToLayoutData(parsedData) {
        // Convert AI parsed data to our LayoutData structure
        const frames = parsedData.components?.map((comp, index)=>({
                id: `frame-${index}`,
                name: comp.name,
                type: 'FRAME',
                x: comp.layout?.x || 0,
                y: comp.layout?.y || 0,
                width: comp.layout?.width || 200,
                height: comp.layout?.height || 50,
                backgroundColor: parsedData.layout?.colors?.background || '#FFFFFF',
                children: [],
                constraints: {
                    horizontal: 'MIN',
                    vertical: 'MIN'
                }
            })) || [];
        return {
            id: `layout-${Date.now()}`,
            name: 'Generated Layout',
            frames,
            styles: {
                colors: Object.entries(parsedData.layout?.colors || {}).map(([name, value])=>({
                        name,
                        value: this.hexToRgba(value),
                        description: `${name} color`
                    })),
                typography: [],
                spacing: Object.entries(parsedData.layout?.spacing || {}).map(([name, value])=>({
                        name,
                        value: value,
                        description: `${name} spacing`
                    })),
                borderRadius: [],
                shadows: []
            },
            metadata: {
                version: '1.0.0',
                generatedAt: new Date(),
                aiModel: 'gemini-1.5-flash',
                requirements: parsedData.requirements || '',
                theme: parsedData.layout?.theme || 'light'
            }
        };
    }
    hexToRgba(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        if (!result) {
            return {
                r: 0,
                g: 0,
                b: 0,
                a: 1
            };
        }
        return {
            r: parseInt(result[1], 16) / 255,
            g: parseInt(result[2], 16) / 255,
            b: parseInt(result[3], 16) / 255,
            a: 1
        };
    }
}
}),
"[project]/src/utils/replicate-ai.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ReplicateAIService",
    ()=>ReplicateAIService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$replicate$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/replicate/index.js [app-route] (ecmascript)");
;
class ReplicateAIService {
    replicate;
    constructor(apiKey){
        this.replicate = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$replicate$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"]({
            auth: apiKey
        });
    }
    async generateImage(prompt) {
        console.log('🎨 [REPLICATE AI] Starting image generation...');
        console.log('📝 [REPLICATE AI] Prompt:', prompt.substring(0, 100) + '...');
        try {
            // Use a working image generation model
            const output = await this.replicate.run("stability-ai/sdxl:39ed52f2a78e934b3ba6e2a89f5b1c712de7dfea535525255b1aa35c5565e08b", {
                input: {
                    prompt: prompt,
                    width: 1024,
                    height: 768,
                    num_inference_steps: 20,
                    guidance_scale: 7.5,
                    num_outputs: 1
                }
            });
            console.log('✅ [REPLICATE AI] Image generated successfully');
            console.log('🖼️ [REPLICATE AI] Output type:', typeof output);
            // Handle different output formats
            let imageUrl;
            if (Array.isArray(output)) {
                imageUrl = output[0];
            } else {
                imageUrl = output;
            }
            return {
                success: true,
                layoutData: {
                    image: imageUrl,
                    prompt: prompt,
                    generatedAt: new Date().toISOString()
                }
            };
        } catch (error) {
            console.error('❌ [REPLICATE AI] Image generation failed:', error);
            return {
                success: false,
                error: `Replicate image generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`
            };
        }
    }
    // Alternative method using different models
    async generateImageWithModel(prompt, model = "stability-ai/stable-diffusion") {
        console.log('🎨 [REPLICATE AI] Starting image generation with model:', model);
        console.log('📝 [REPLICATE AI] Prompt:', prompt.substring(0, 100) + '...');
        try {
            const output = await this.replicate.run(model, {
                input: {
                    prompt: prompt,
                    width: 1024,
                    height: 768,
                    num_inference_steps: 20,
                    guidance_scale: 7.5,
                    num_outputs: 1
                }
            });
            console.log('✅ [REPLICATE AI] Image generated successfully with model:', model);
            let imageUrl;
            if (Array.isArray(output)) {
                imageUrl = output[0];
            } else {
                imageUrl = output;
            }
            return {
                success: true,
                layoutData: {
                    image: imageUrl,
                    prompt: prompt,
                    model: model,
                    generatedAt: new Date().toISOString()
                }
            };
        } catch (error) {
            console.error('❌ [REPLICATE AI] Image generation failed with model:', model, error);
            return {
                success: false,
                error: `Replicate image generation failed with model ${model}: ${error instanceof Error ? error.message : 'Unknown error'}`
            };
        }
    }
}
}),
"[project]/src/utils/deepai-ai.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DeepAIService",
    ()=>DeepAIService
]);
class DeepAIService {
    apiKey;
    constructor(apiKey){
        this.apiKey = apiKey;
    }
    async generateImage(prompt) {
        console.log('🎨 [DEEPAI] Starting image generation...');
        console.log('📝 [DEEPAI] Prompt:', prompt.substring(0, 100) + '...');
        try {
            const response = await fetch('https://api.deepai.org/api/text2img', {
                method: 'POST',
                headers: {
                    'Api-Key': this.apiKey,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    text: prompt,
                    width: '1024',
                    height: '768'
                })
            });
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`DeepAI API error: ${response.status} - ${errorText}`);
            }
            const data = await response.json();
            console.log('✅ [DEEPAI] Image generated successfully');
            console.log('🖼️ [DEEPAI] Response:', data);
            if (data.output_url) {
                return {
                    success: true,
                    layoutData: {
                        image: data.output_url
                    },
                    message: 'Image generated successfully by DeepAI'
                };
            } else {
                throw new Error('DeepAI returned an unexpected response format');
            }
        } catch (error) {
            console.error('❌ [DEEPAI] DeepAI image generation failed:', error);
            return {
                success: false,
                error: `DeepAI image generation failed: ${error.message || error}`,
                layoutData: null
            };
        }
    }
}
}),
"[project]/src/lib/config.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Configuration for Laygen application
__turbopack_context__.s([
    "config",
    ()=>config,
    "getEnvVar",
    ()=>getEnvVar,
    "isDevelopment",
    ()=>isDevelopment,
    "isProduction",
    ()=>isProduction,
    "validateConfig",
    ()=>validateConfig
]);
const config = {
    // API Keys (set these in your environment variables)
    figma: {
        apiKey: process.env.FIGMA_API_KEY || '',
        webhookSecret: ("TURBOPACK compile-time value", "DzC8zcPFdWQbTfUvyA0ycsW4gqhsFs") || '',
        baseUrl: 'https://api.figma.com/v1'
    },
    ai: {
        provider: 'gemini',
        apiKey: process.env.GEMINI_API_KEY || '',
        model: 'gemini-1.5-flash',
        fallbackProvider: 'openai',
        fallbackApiKey: process.env.OPENAI_API_KEY || '',
        fallbackModel: 'gpt-3.5-turbo'
    },
    // Replicate AI for image generation
    replicate: {
        apiKey: process.env.REPLICATE_API_TOKEN || '',
        defaultModel: 'stability-ai/stable-diffusion:db21e45d3f7023abc2a46e38a211633768e4ea5badbff3d474b0a0b3a1866d9',
        imageGeneration: {
            width: 1024,
            height: 768,
            numInferenceSteps: 20,
            guidanceScale: 7.5,
            numOutputs: 1
        }
    },
    // DeepAI for image generation
    deepai: {
        apiKey: process.env.DEEPAI_API_KEY || '',
        imageGeneration: {
            width: 1024,
            height: 768
        }
    },
    app: {
        url: ("TURBOPACK compile-time value", "http://localhost:3000") || 'http://localhost:3000',
        name: 'Laygen',
        description: 'From Requirements to Ready UI — Instantly'
    },
    // File upload limits
    upload: {
        maxFileSize: 10 * 1024 * 1024,
        allowedTypes: [
            'text/plain',
            'text/markdown',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ],
        allowedExtensions: [
            '.txt',
            '.md',
            '.pdf',
            '.doc',
            '.docx'
        ]
    },
    // Figma integration settings
    figmaSettings: {
        defaultFrameWidth: 1440,
        defaultFrameHeight: 1024,
        defaultSpacing: 16,
        defaultBorderRadius: 8
    },
    // Code generation settings
    codeGeneration: {
        defaultFramework: 'nextjs',
        includeTypeScript: true,
        includeTailwindCSS: true,
        includeResponsiveDesign: true
    }
};
function validateConfig() {
    const errors = [];
    if (!config.figma.apiKey) {
        errors.push('FIGMA_API_KEY is required');
    }
    if (!config.ai.apiKey) {
        errors.push('GEMINI_API_KEY is required');
    }
    if (config.ai.fallbackProvider === 'openai' && !config.ai.fallbackApiKey) {
        errors.push('OPENAI_API_KEY is required as fallback');
    }
    if (!config.replicate.apiKey) {
        errors.push('REPLICATE_API_TOKEN is required for image generation');
    }
    if (!config.deepai.apiKey) {
        errors.push('DEEPAI_API_KEY is required for image generation');
    }
    return {
        valid: errors.length === 0,
        errors
    };
}
function getEnvVar(key, fallback = '') {
    return process.env[key] || fallback;
}
const isDevelopment = ("TURBOPACK compile-time value", "development") === 'development';
const isProduction = ("TURBOPACK compile-time value", "development") === 'production';
}),
"[project]/src/utils/ai.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AIService",
    ()=>AIService,
    "createAIService",
    ()=>createAIService,
    "parseDocumentContent",
    ()=>parseDocumentContent,
    "validateDocument",
    ()=>validateDocument
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$gemini$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/gemini-ai.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$replicate$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/replicate-ai.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$deepai$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/deepai-ai.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/config.ts [app-route] (ecmascript)");
;
;
;
;
;
// Hybrid AI service that uses Gemini for text and DeepAI for images
class DeepAIHybridService {
    geminiService;
    deepaiService;
    constructor(geminiApiKey, deepaiApiKey){
        this.geminiService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$gemini$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GeminiAIService"](geminiApiKey);
        this.deepaiService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$deepai$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DeepAIService"](deepaiApiKey);
    }
    async parseDocument(document) {
        return this.geminiService.parseDocument(document);
    }
    async generateLayoutVariations(layoutData) {
        return this.geminiService.generateLayoutVariations(layoutData);
    }
    async generateCode(layoutData, framework = 'nextjs') {
        return this.geminiService.generateCode(layoutData, framework);
    }
    async generateImage(prompt) {
        // Use DeepAI for image generation
        return this.deepaiService.generateImage(prompt);
    }
}
// Hybrid AI service that uses Gemini for text and Replicate for images
class HybridAIService {
    geminiService;
    replicateService;
    constructor(geminiApiKey, replicateApiKey){
        this.geminiService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$gemini$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GeminiAIService"](geminiApiKey);
        this.replicateService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$replicate$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ReplicateAIService"](replicateApiKey);
    }
    async parseDocument(document) {
        return this.geminiService.parseDocument(document);
    }
    async generateLayoutVariations(layoutData) {
        return this.geminiService.generateLayoutVariations(layoutData);
    }
    async generateCode(layoutData, framework = 'nextjs') {
        return this.geminiService.generateCode(layoutData, framework);
    }
    async generateImage(prompt) {
        // Use Replicate for image generation
        return this.replicateService.generateImage(prompt);
    }
}
// Legacy hybrid service that uses Gemini for text and OpenAI for images
class LegacyHybridAIService {
    geminiService;
    openaiService;
    constructor(geminiApiKey, openaiApiKey){
        this.geminiService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$gemini$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GeminiAIService"](geminiApiKey);
        this.openaiService = new AIService(openaiApiKey);
    }
    async parseDocument(document) {
        return this.geminiService.parseDocument(document);
    }
    async generateLayoutVariations(layoutData) {
        return this.geminiService.generateLayoutVariations(layoutData);
    }
    async generateCode(layoutData, framework = 'nextjs') {
        return this.geminiService.generateCode(layoutData, framework);
    }
    async generateImage(prompt) {
        // Use OpenAI for image generation since Gemini doesn't support it
        return this.openaiService.generateImage(prompt);
    }
}
// Robust AI service with automatic fallback
class RobustAIService {
    primaryService;
    fallbackService;
    serviceName;
    constructor(primaryService, fallbackService, serviceName){
        this.primaryService = primaryService;
        this.fallbackService = fallbackService;
        this.serviceName = serviceName;
    }
    async parseDocument(document) {
        try {
            return await this.primaryService.parseDocument(document);
        } catch (error) {
            console.log(`⚠️ [ROBUST AI] Primary service failed, trying fallback...`);
            return await this.fallbackService.parseDocument(document);
        }
    }
    async generateLayoutVariations(layoutData) {
        try {
            return await this.primaryService.generateLayoutVariations(layoutData);
        } catch (error) {
            console.log(`⚠️ [ROBUST AI] Primary service failed, trying fallback...`);
            return await this.fallbackService.generateLayoutVariations(layoutData);
        }
    }
    async generateCode(layoutData, framework = 'nextjs') {
        try {
            return await this.primaryService.generateCode(layoutData, framework);
        } catch (error) {
            console.log(`⚠️ [ROBUST AI] Primary service failed, trying fallback...`);
            return await this.fallbackService.generateCode(layoutData, framework);
        }
    }
    async generateImage(prompt) {
        try {
            return await this.primaryService.generateImage(prompt);
        } catch (error) {
            console.log(`⚠️ [ROBUST AI] Primary service failed, trying fallback...`);
            return await this.fallbackService.generateImage(prompt);
        }
    }
}
function createAIService() {
    const provider = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].ai.provider;
    const apiKey = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].ai.apiKey;
    const fallbackApiKey = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].ai.fallbackApiKey;
    const replicateApiKey = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].replicate.apiKey;
    const deepaiApiKey = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].deepai.apiKey;
    if (provider === 'gemini' && apiKey && deepaiApiKey) {
        console.log('Using DeepAI Hybrid service (Gemini for text, DeepAI for images)');
        const primaryService = new DeepAIHybridService(apiKey, deepaiApiKey);
        if (fallbackApiKey) {
            const fallbackService = new LegacyHybridAIService(apiKey, fallbackApiKey);
            return new RobustAIService(primaryService, fallbackService, 'DeepAI Hybrid with OpenAI fallback');
        }
        return primaryService;
    } else if (provider === 'gemini' && apiKey && replicateApiKey) {
        console.log('Using Hybrid AI service (Gemini for text, Replicate for images)');
        const primaryService = new HybridAIService(apiKey, replicateApiKey);
        if (fallbackApiKey) {
            const fallbackService = new LegacyHybridAIService(apiKey, fallbackApiKey);
            return new RobustAIService(primaryService, fallbackService, 'Hybrid with OpenAI fallback');
        }
        return primaryService;
    } else if (provider === 'gemini' && apiKey && fallbackApiKey) {
        console.log('Using Legacy Hybrid AI service (Gemini for text, OpenAI for images)');
        return new LegacyHybridAIService(apiKey, fallbackApiKey);
    } else if (provider === 'gemini' && apiKey) {
        console.log('Using Gemini AI service (no image generation)');
        const primaryService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$gemini$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["GeminiAIService"](apiKey);
        if (fallbackApiKey) {
            const fallbackService = new AIService(fallbackApiKey);
            return new RobustAIService(primaryService, fallbackService, 'Gemini with OpenAI fallback');
        }
        return primaryService;
    } else if (apiKey) {
        console.log('Using OpenAI service');
        return new AIService(apiKey);
    } else {
        // Fallback to OpenAI if Gemini fails
        if (fallbackApiKey) {
            console.log('Falling back to OpenAI service');
            return new AIService(fallbackApiKey);
        }
        throw new Error('No valid AI service configuration found');
    }
}
class AIService {
    apiKey;
    availableModels = [
        'gpt-3.5-turbo',
        'gpt-4',
        'gpt-4-turbo'
    ];
    baseURL = 'https://api.openai.com/v1';
    constructor(apiKey){
        this.apiKey = apiKey;
    }
    async tryModels(prompt, systemMessage, options) {
        const errors = [];
        // Adding retries for model switching, with specific handling of 404 (model not found)
        for (const model of this.availableModels){
            try {
                console.log(`Trying model: ${model}`);
                console.log(`API Key present: ${!!this.apiKey}`);
                console.log(`API Key length: ${this.apiKey.length}`);
                console.log(`API Key starts with: ${this.apiKey.substring(0, 10)}...`);
                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].post(`${this.baseURL}/chat/completions`, {
                    model,
                    messages: [
                        {
                            role: 'system',
                            content: systemMessage
                        },
                        {
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: options.temperature,
                    max_tokens: options.max_tokens
                }, {
                    headers: {
                        'Authorization': `Bearer ${this.apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 60000 // 60 second timeout
                });
                // Log successful model use
                console.log(`Model ${model} succeeded`);
                console.log(`Response status: ${response.status}`);
                return response.data;
            } catch (error) {
                const axiosError = error; // eslint-disable-line @typescript-eslint/no-explicit-any
                const status = axiosError?.response?.status;
                // Handle specific error cases
                if (status === 404) {
                    console.warn(`Model ${model} not found, skipping to next model.`);
                } else if (status === 429) {
                    console.warn(`Model ${model} rate limited, trying next model.`);
                } else if (status === 401) {
                    console.error(`Model ${model} unauthorized - API key issue.`);
                } else if (status === 403) {
                    console.error(`Model ${model} forbidden - check API key permissions.`);
                }
                const errorMessage = error instanceof Error ? error.message : 'Unknown error';
                const detailedError = axiosError?.response ? `Status: ${axiosError.response.status}, Data: ${JSON.stringify(axiosError.response.data)}` : errorMessage;
                console.error(`Model ${model} failed:`, detailedError);
                errors.push(`${model}: ${detailedError}`);
            }
        }
        // Analyze error types to provide better guidance
        const hasQuotaErrors = errors.some((err)=>err.includes('429') || err.includes('quota') || err.includes('billing'));
        const hasAuthErrors = errors.some((err)=>err.includes('401') || err.includes('403') || err.includes('unauthorized'));
        const hasModelErrors = errors.some((err)=>err.includes('404') || err.includes('not found'));
        let solutionMessage = 'Possible solutions:\n';
        if (hasAuthErrors) {
            solutionMessage += '1) Check your OpenAI API key is valid and has proper permissions\n';
        } else {
            solutionMessage += '1) Check your OpenAI API key is valid\n';
        }
        if (hasQuotaErrors) {
            solutionMessage += '2) Add payment method and credits to your OpenAI account\n';
        } else {
            solutionMessage += '2) Verify you have credits/quota available\n';
        }
        if (hasModelErrors) {
            solutionMessage += '3) Check your OpenAI plan includes the requested models\n';
        } else {
            solutionMessage += '3) Check your OpenAI plan includes the models\n';
        }
        solutionMessage += '4) Try again in a few minutes if rate limited\n';
        solutionMessage += '5) Visit https://platform.openai.com/account/billing to manage your account';
        const detailedError = `All AI models failed. Errors:\n${errors.join('\n')}\n\n${solutionMessage}`;
        throw new Error(detailedError);
    }
    async parseDocument(document) {
        try {
            // Check if this is Excel data
            let isExcelData = false;
            try {
                const parsedContent = JSON.parse(document.content);
                isExcelData = parsedContent.type === 'excel_data';
            } catch  {
            // Not JSON, continue with normal parsing
            }
            let prompt;
            if (isExcelData) {
                // Simple Excel file analysis - just use file info, no complex parsing
                const fileInfo = JSON.parse(document.content);
                prompt = `
          Create a web application based on this Excel file description. The user wants to build a data management application.
          
          File Information:
          - File Name: ${fileInfo.fileName}
          - File Size: ${fileInfo.fileSize} bytes
          - File Type: ${fileInfo.fileType}
          
          Generate a complete application design with the following structure:
          {
            "dataAnalysis": {
              "dataType": "Data Management Application",
              "columns": ["Title", "Description", "Type", "Priority", "Status"],
              "recordCount": "Multiple records",
              "dataPatterns": "Structured data with title, description, type, priority, and status fields",
              "suggestedAppType": "Task/Project Management Dashboard",
              "projectName": "${fileInfo.fileName.replace(/\.(xlsx|xls)$/i, '')}",
              "titleColumn": "Title"
            },
            "designOptions": [
              {
                "id": "dashboard_1",
                "name": "Modern Dashboard",
                "description": "Clean dashboard with cards and filters",
                "preview": "Modern card-based layout with search and filter options",
                "components": [
                  {
                    "name": "Header",
                    "type": "header",
                    "description": "Application header with title and search",
                    "properties": {
                      "title": "Project Management",
                      "showSearch": true
                    },
                    "layout": {
                      "x": 0,
                      "y": 0,
                      "width": 1200,
                      "height": 80
                    }
                  },
                  {
                    "name": "FilterBar",
                    "type": "filter",
                    "description": "Filter controls for type and priority",
                    "properties": {
                      "filters": ["Type", "Priority", "Status"]
                    },
                    "layout": {
                      "x": 0,
                      "y": 80,
                      "width": 1200,
                      "height": 60
                    }
                  },
                  {
                    "name": "DataGrid",
                    "type": "table",
                    "description": "Main data display table",
                    "properties": {
                      "columns": ["Title", "Description", "Type", "Priority", "Status", "Actions"],
                      "sortable": true,
                      "editable": true
                    },
                    "layout": {
                      "x": 0,
                      "y": 140,
                      "width": 1200,
                      "height": 400
                    }
                  }
                ],
                "layout": {
                  "type": "dashboard",
                  "theme": "light",
                  "colors": {
                    "primary": "#3B82F6",
                    "secondary": "#6B7280",
                    "background": "#FFFFFF",
                    "text": "#111827"
                  }
                }
              },
              {
                "id": "card_2",
                "name": "Card Layout",
                "description": "Card-based layout for better visual appeal",
                "preview": "Grid of cards showing each data item",
                "components": [
                  {
                    "name": "CardGrid",
                    "type": "grid",
                    "description": "Grid of data cards",
                    "properties": {
                      "columns": 3,
                      "cardType": "data"
                    },
                    "layout": {
                      "x": 0,
                      "y": 0,
                      "width": 1200,
                      "height": 600
                    }
                  }
                ],
                "layout": {
                  "type": "grid",
                  "theme": "light",
                  "colors": {
                    "primary": "#10B981",
                    "secondary": "#6B7280",
                    "background": "#F9FAFB",
                    "text": "#111827"
                  }
                }
              }
            ],
            "requirements": "Create a responsive web application for managing structured data with CRUD operations, filtering, and search functionality"
          }
        `;
            } else {
                // Normal document parsing
                prompt = `
          Analyze the following document and extract design requirements. 
          Return a JSON object with the following structure:
          {
            "components": [
              {
                "name": "Component Name",
                "type": "button|input|card|header|footer|etc",
                "description": "What this component does",
                "properties": {
                  "text": "Button text",
                  "color": "primary|secondary|etc",
                  "size": "small|medium|large",
                  "position": "top|center|bottom|left|right"
                },
                "layout": {
                  "x": 0,
                  "y": 0,
                  "width": 200,
                  "height": 50
                }
              }
            ],
            "layout": {
              "type": "single-page|multi-page|dashboard|landing",
              "theme": "light|dark|auto",
              "colors": {
                "primary": "#3B82F6",
                "secondary": "#6B7280",
                "background": "#FFFFFF",
                "text": "#111827"
              },
              "typography": {
                "heading": "Inter Bold",
                "body": "Inter Regular",
                "sizes": {
                  "h1": 32,
                  "h2": 24,
                  "h3": 20,
                  "body": 16,
                  "small": 14
                }
              },
              "spacing": {
                "xs": 4,
                "sm": 8,
                "md": 16,
                "lg": 24,
                "xl": 32
              }
            },
            "requirements": "Summary of key requirements"
          }

          Document content:
          ${document.content}
        `;
            }
            const response = await this.tryModels(prompt, 'You are a design system expert. Analyze documents and extract structured design requirements. Always return valid JSON.', {
                temperature: 0.3,
                max_tokens: 2000
            });
            const content = response.choices[0]?.message?.content;
            if (!content) {
                throw new Error('No response from AI');
            }
            const parsedData = JSON.parse(content);
            const layoutData = this.convertToLayoutData(parsedData);
            return {
                success: true,
                layoutData,
                confidence: 0.85,
                suggestions: [
                    'Consider adding hover states for interactive elements',
                    'Ensure proper contrast ratios for accessibility',
                    'Add responsive breakpoints for mobile devices'
                ]
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Failed to parse document',
                confidence: 0
            };
        }
    }
    async generateLayoutVariations(baseLayout, count = 2) {
        try {
            const prompt = `
        Based on this existing layout, generate ${count} alternative variations that maintain the same functionality but with different visual arrangements.
        
        Current layout:
        ${JSON.stringify(baseLayout, null, 2)}
        
        Return a JSON array with ${count} layout variations, each following the same structure as the input layout.
        Focus on:
        - Different component arrangements
        - Alternative color schemes
        - Varied spacing and sizing
        - Different visual hierarchy
        - Maintain accessibility and usability
      `;
            const response = await this.tryModels(prompt, 'You are a UI/UX designer. Generate creative layout variations while maintaining functionality and usability. Always return valid JSON arrays.', {
                temperature: 0.7,
                max_tokens: 3000
            });
            const content = response.choices[0]?.message?.content;
            if (!content) {
                throw new Error('No response from AI');
            }
            const variations = JSON.parse(content);
            return {
                success: true,
                layoutData: variations[0],
                confidence: 0.8,
                suggestions: [
                    'Try different color combinations',
                    'Experiment with component positioning',
                    'Consider alternative typography scales'
                ]
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Failed to generate variations',
                confidence: 0
            };
        }
    }
    async generateImage(prompt) {
        try {
            console.log('Generating image with prompt:', prompt.substring(0, 100) + '...');
            console.log(`API Key present: ${!!this.apiKey}`);
            console.log(`API Key length: ${this.apiKey.length}`);
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].post(`${this.baseURL}/images/generations`, {
                model: "dall-e-3",
                prompt: prompt,
                n: 1,
                size: "1024x1024",
                quality: "standard",
                style: "natural"
            }, {
                headers: {
                    'Authorization': `Bearer ${this.apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 120000 // 2 minute timeout for image generation
            });
            console.log('Image generation response status:', response.status);
            console.log('Image generation response data:', response.data);
            return {
                success: true,
                layoutData: {
                    imageUrl: response.data?.data?.[0]?.url || '',
                    prompt: prompt
                },
                confidence: 0.9
            };
        } catch (error) {
            console.error('Image generation error:', error);
            const axiosError = error; // eslint-disable-line @typescript-eslint/no-explicit-any
            const errorMessage = axiosError.response ? `Status: ${axiosError.response.status}, Data: ${JSON.stringify(axiosError.response.data)}` : error instanceof Error ? error.message : 'Failed to generate image';
            return {
                success: false,
                error: errorMessage,
                confidence: 0
            };
        }
    }
    async generateCode(layoutData, framework = 'html') {
        try {
            const prompt = `
        Generate a complete, working HTML, CSS, and JavaScript application based on the provided data and design requirements.
        Create a single-page application that can be run immediately by opening the HTML file in a browser.
        
        IMPORTANT: Analyze the layout data to understand:
        - What type of application this should be
        - What data fields/columns are present
        - What functionality is needed based on the data structure
        - What UI components are required
        - Use the project name and selected colors from the data
        - Generate features and functionality based on the actual data, not hardcoded assumptions
        
        Return a JSON object with this structure:
        {
          "html": {
            "index": "<!DOCTYPE html><html><head>...</head><body>...</body></html>",
            "title": "Project Name"
          },
          "css": {
            "main": "/* Complete CSS styles with your selected colors */",
            "variables": ":root { /* CSS custom properties for colors */ }"
          },
          "javascript": {
            "main": "// Complete JavaScript functionality",
            "data": "// Sample data based on your Excel structure"
          },
          "features": [
            "Add new items",
            "Edit existing items", 
            "Filter and search",
            "Delete items",
            "Responsive design"
          ],
          "instructions": "Simply open index.html in any web browser to run the application"
        }

        Layout data to analyze:
        ${JSON.stringify(layoutData, null, 2)}
      `;
            const response = await this.tryModels(prompt, `You are a senior ${framework} developer. Generate clean, production-ready code with proper TypeScript types, accessibility features, and responsive design. Always return valid JSON.`, {
                temperature: 0.2,
                max_tokens: 4000
            });
            const content = response.choices[0]?.message?.content;
            if (!content) {
                throw new Error('No response from AI');
            }
            const codeData = JSON.parse(content);
            return {
                success: true,
                layoutData: codeData,
                confidence: 0.9,
                suggestions: [
                    'Add proper error boundaries',
                    'Implement loading states',
                    'Add unit tests for components',
                    'Consider performance optimizations'
                ]
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Failed to generate code',
                confidence: 0
            };
        }
    }
    convertToLayoutData(parsedData) {
        // Convert AI parsed data to our LayoutData structure
        const frames = parsedData.components?.map((comp, index)=>({
                id: `frame-${index}`,
                name: comp.name,
                type: 'FRAME',
                x: comp.layout?.x || 0,
                y: comp.layout?.y || 0,
                width: comp.layout?.width || 200,
                height: comp.layout?.height || 50,
                backgroundColor: parsedData.layout?.colors?.background || '#FFFFFF',
                children: [],
                constraints: {
                    horizontal: 'MIN',
                    vertical: 'MIN'
                }
            })) || [];
        return {
            id: `layout-${Date.now()}`,
            name: 'Generated Layout',
            frames,
            styles: {
                colors: Object.entries(parsedData.layout?.colors || {}).map(([name, value])=>({
                        name,
                        value: this.hexToRgba(value),
                        description: `${name} color`
                    })),
                typography: [],
                spacing: Object.entries(parsedData.layout?.spacing || {}).map(([name, value])=>({
                        name,
                        value: value,
                        description: `${name} spacing`
                    })),
                borderRadius: [],
                shadows: []
            },
            metadata: {
                version: '1.0.0',
                generatedAt: new Date(),
                aiModel: 'gpt-4',
                requirements: parsedData.requirements || '',
                theme: parsedData.layout?.theme || 'light'
            }
        };
    }
    hexToRgba(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        if (!result) {
            return {
                r: 0,
                g: 0,
                b: 0,
                a: 1
            };
        }
        return {
            r: parseInt(result[1], 16) / 255,
            g: parseInt(result[2], 16) / 255,
            b: parseInt(result[3], 16) / 255,
            a: 1
        };
    }
}
async function parseDocumentContent(file) {
    // Handle Excel files
    if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel' || file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        return await parseExcelFile(file);
    }
    // Handle text files
    if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
        return await file.text();
    }
    if (file.type === 'text/markdown' || file.name.endsWith('.md')) {
        return await file.text();
    }
    // For PDF, DOC, DOCX - you'd integrate with libraries like pdf-parse, mammoth, etc.
    // For now, return the raw text
    return await file.text();
}
// Excel parsing function - Dynamic analysis
async function parseExcelFile(file) {
    try {
        // For now, we'll use a simple approach without external libraries
        // In production, you'd use the xlsx library
        await file.arrayBuffer(); // Read the file to validate it's accessible
        // Return a dynamic structure that will be analyzed by AI
        return JSON.stringify({
            type: 'excel_data',
            fileName: file.name,
            fileSize: file.size,
            fileType: file.type,
            note: 'Excel file detected. AI will analyze the actual content structure and data patterns to generate appropriate design options and application type.'
        });
    } catch (error) {
        throw new Error('Failed to parse Excel file: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
}
function validateDocument(file) {
    const allowedTypes = [
        'text/plain',
        'text/markdown',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel'
    ];
    const allowedExtensions = [
        '.txt',
        '.md',
        '.pdf',
        '.doc',
        '.docx',
        '.xlsx',
        '.xls'
    ];
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!allowedTypes.includes(file.type) && !allowedExtensions.includes(fileExtension)) {
        return {
            valid: false,
            error: 'Unsupported file type. Please upload PDF, DOC, DOCX, TXT, MD, or Excel files.'
        };
    }
    if (file.size > 10 * 1024 * 1024) {
        return {
            valid: false,
            error: 'File size too large. Please upload files smaller than 10MB.'
        };
    }
    return {
        valid: true
    };
}
}),
"[project]/src/app/api/figma/generate-designs/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/ai.ts [app-route] (ecmascript)");
;
;
async function POST(request) {
    console.log('🎨 [DESIGN API] Starting design generation process...');
    const startTime = Date.now();
    try {
        console.log('📥 [DESIGN API] Extracting request data...');
        const { prompt, dataAnalysis } = await request.json();
        console.log('📋 [DESIGN API] Request data:', {
            hasPrompt: !!prompt,
            hasDataAnalysis: !!dataAnalysis,
            promptLength: prompt?.length || 0
        });
        if (!prompt && !dataAnalysis) {
            console.log('❌ [DESIGN API] No prompt or data analysis provided');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Prompt or data analysis is required'
            }, {
                status: 400
            });
        }
        console.log('🤖 [DESIGN API] Creating AI service for design generation...');
        const aiService = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAIService"])();
        console.log('✅ [DESIGN API] AI service created successfully');
        // Create a test document for AI processing with a more specific prompt
        const enhancedPrompt = prompt || 'Create a modern dashboard for a task management app';
        const testDocument = {
            id: 'design-gen-doc',
            name: 'design-requirements.txt',
            type: 'txt',
            size: 1024,
            content: `Design Requirements: ${enhancedPrompt}

Please generate 4 different design options for this application with distinct color schemes. Each design should include:
- A unique name and description
- A list of components (header, sidebar, main content, etc.)
- Layout specifications (position, size)
- Different color scheme for each design
- Theme information

IMPORTANT: Return ONLY valid JSON. Do not include any markdown formatting, explanations, or text outside the JSON. All property names must be in double quotes. All string values must be in double quotes.

Return the data in this exact JSON format:
{
  "designOptions": [
    {
      "id": "design-1",
      "name": "Modern Blue Dashboard",
      "description": "Clean and modern design with blue color scheme",
      "preview": "Card-based layout with blue accents",
      "components": [
        {
          "name": "Header",
          "type": "header",
          "description": "Top navigation bar",
          "properties": {"title": "Dashboard", "showSearch": true},
          "layout": {"x": 0, "y": 0, "width": 1200, "height": 80}
        }
      ],
      "layout": {
        "type": "dashboard",
        "theme": "light",
        "colors": {
          "primary": "#3B82F6",
          "secondary": "#6B7280",
          "background": "#FFFFFF",
          "text": "#111827"
        }
      }
    },
    {
      "id": "design-2",
      "name": "Green Professional",
      "description": "Professional design with green color scheme",
      "preview": "Clean layout with green accents",
      "components": [
        {
          "name": "Header",
          "type": "header",
          "description": "Top navigation bar",
          "properties": {"title": "Dashboard", "showSearch": true},
          "layout": {"x": 0, "y": 0, "width": 1200, "height": 80}
        }
      ],
      "layout": {
        "type": "professional",
        "theme": "light",
        "colors": {
          "primary": "#10B981",
          "secondary": "#6B7280",
          "background": "#F9FAFB",
          "text": "#111827"
        }
      }
    },
    {
      "id": "design-3",
      "name": "Purple Creative",
      "description": "Creative design with purple color scheme",
      "preview": "Modern layout with purple accents",
      "components": [
        {
          "name": "Header",
          "type": "header",
          "description": "Top navigation bar",
          "properties": {"title": "Dashboard", "showSearch": true},
          "layout": {"x": 0, "y": 0, "width": 1200, "height": 80}
        }
      ],
      "layout": {
        "type": "creative",
        "theme": "light",
        "colors": {
          "primary": "#8B5CF6",
          "secondary": "#A78BFA",
          "background": "#FFFFFF",
          "text": "#111827"
        }
      }
    },
    {
      "id": "design-4",
      "name": "Orange Energetic",
      "description": "Energetic design with orange color scheme",
      "preview": "Dynamic layout with orange accents",
      "components": [
        {
          "name": "Header",
          "type": "header",
          "description": "Top navigation bar",
          "properties": {"title": "Dashboard", "showSearch": true},
          "layout": {"x": 0, "y": 0, "width": 1200, "height": 80}
        }
      ],
      "layout": {
        "type": "energetic",
        "theme": "light",
        "colors": {
          "primary": "#F59E0B",
          "secondary": "#FCD34D",
          "background": "#FFFBEB",
          "text": "#111827"
        }
      }
    }
  ],
  "colorCombinations": [
    {
      "name": "Blue Theme",
      "colors": {
        "primary": "#3B82F6",
        "secondary": "#6B7280",
        "background": "#FFFFFF",
        "text": "#111827"
      },
      "preview": "Clean blue and gray color scheme"
    },
    {
      "name": "Green Theme",
      "colors": {
        "primary": "#10B981",
        "secondary": "#6B7280",
        "background": "#F9FAFB",
        "text": "#111827"
      },
      "preview": "Professional green color scheme"
    },
    {
      "name": "Purple Theme",
      "colors": {
        "primary": "#8B5CF6",
        "secondary": "#A78BFA",
        "background": "#FFFFFF",
        "text": "#111827"
      },
      "preview": "Creative purple color scheme"
    },
    {
      "name": "Orange Theme",
      "colors": {
        "primary": "#F59E0B",
        "secondary": "#FCD34D",
        "background": "#FFFBEB",
        "text": "#111827"
      },
      "preview": "Energetic orange color scheme"
    }
  ]
}`,
            uploadedAt: new Date()
        };
        // Process with AI to generate design options
        console.log('🧠 [DESIGN API] Processing document with AI service...');
        console.log('📝 [DESIGN API] Enhanced prompt:', enhancedPrompt.substring(0, 100) + '...');
        let result;
        try {
            console.log('🤖 [DESIGN API] Calling AI service parseDocument...');
            result = await aiService.parseDocument(testDocument);
            console.log('✅ [DESIGN API] AI service response received:', result.success ? 'Success' : 'Failed');
        } catch (error) {
            console.error('❌ [DESIGN API] AI service threw an error:', error);
            console.log('🔄 [DESIGN API] Using fallback designs due to AI service error');
            // Use fallback designs if AI service completely fails
            result = {
                success: true,
                layoutData: {
                    designOptions: [
                        {
                            id: 'fallback-1',
                            name: 'Modern Blue Dashboard',
                            description: 'Clean and modern design with blue color scheme',
                            preview: 'Card-based layout with blue accents',
                            components: [
                                {
                                    name: 'Header',
                                    type: 'header',
                                    description: 'Top navigation bar',
                                    properties: {
                                        title: 'Dashboard',
                                        showSearch: true
                                    },
                                    layout: {
                                        x: 0,
                                        y: 0,
                                        width: 1200,
                                        height: 80
                                    }
                                },
                                {
                                    name: 'Main Content',
                                    type: 'main',
                                    description: 'Main content area',
                                    properties: {
                                        scrollable: true
                                    },
                                    layout: {
                                        x: 0,
                                        y: 80,
                                        width: 1200,
                                        height: 720
                                    }
                                }
                            ],
                            layout: {
                                type: 'dashboard',
                                theme: 'light',
                                colors: {
                                    primary: '#3B82F6',
                                    secondary: '#6B7280',
                                    background: '#FFFFFF',
                                    text: '#111827'
                                }
                            }
                        },
                        {
                            id: 'fallback-2',
                            name: 'Green Professional',
                            description: 'Professional design with green color scheme',
                            preview: 'Clean layout with green accents',
                            components: [
                                {
                                    name: 'Header',
                                    type: 'header',
                                    description: 'Top navigation bar',
                                    properties: {
                                        title: 'Dashboard',
                                        showSearch: true
                                    },
                                    layout: {
                                        x: 0,
                                        y: 0,
                                        width: 1200,
                                        height: 80
                                    }
                                },
                                {
                                    name: 'Main Content',
                                    type: 'main',
                                    description: 'Main content area',
                                    properties: {
                                        scrollable: true
                                    },
                                    layout: {
                                        x: 0,
                                        y: 80,
                                        width: 1200,
                                        height: 720
                                    }
                                }
                            ],
                            layout: {
                                type: 'professional',
                                theme: 'light',
                                colors: {
                                    primary: '#10B981',
                                    secondary: '#6B7280',
                                    background: '#F9FAFB',
                                    text: '#111827'
                                }
                            }
                        },
                        {
                            id: 'fallback-3',
                            name: 'Purple Creative',
                            description: 'Creative design with purple color scheme',
                            preview: 'Modern layout with purple accents',
                            components: [
                                {
                                    name: 'Header',
                                    type: 'header',
                                    description: 'Top navigation bar',
                                    properties: {
                                        title: 'Dashboard',
                                        showSearch: true
                                    },
                                    layout: {
                                        x: 0,
                                        y: 0,
                                        width: 1200,
                                        height: 80
                                    }
                                },
                                {
                                    name: 'Main Content',
                                    type: 'main',
                                    description: 'Main content area',
                                    properties: {
                                        scrollable: true
                                    },
                                    layout: {
                                        x: 0,
                                        y: 80,
                                        width: 1200,
                                        height: 720
                                    }
                                }
                            ],
                            layout: {
                                type: 'creative',
                                theme: 'light',
                                colors: {
                                    primary: '#8B5CF6',
                                    secondary: '#A78BFA',
                                    background: '#FFFFFF',
                                    text: '#111827'
                                }
                            }
                        },
                        {
                            id: 'fallback-4',
                            name: 'Orange Energetic',
                            description: 'Energetic design with orange color scheme',
                            preview: 'Dynamic layout with orange accents',
                            components: [
                                {
                                    name: 'Header',
                                    type: 'header',
                                    description: 'Top navigation bar',
                                    properties: {
                                        title: 'Dashboard',
                                        showSearch: true
                                    },
                                    layout: {
                                        x: 0,
                                        y: 0,
                                        width: 1200,
                                        height: 80
                                    }
                                },
                                {
                                    name: 'Main Content',
                                    type: 'main',
                                    description: 'Main content area',
                                    properties: {
                                        scrollable: true
                                    },
                                    layout: {
                                        x: 0,
                                        y: 80,
                                        width: 1200,
                                        height: 720
                                    }
                                }
                            ],
                            layout: {
                                type: 'energetic',
                                theme: 'light',
                                colors: {
                                    primary: '#F59E0B',
                                    secondary: '#FCD34D',
                                    background: '#FFFBEB',
                                    text: '#111827'
                                }
                            }
                        }
                    ],
                    colorCombinations: [
                        {
                            name: 'Blue Theme',
                            colors: {
                                primary: '#3B82F6',
                                secondary: '#6B7280',
                                background: '#FFFFFF',
                                text: '#111827'
                            },
                            preview: 'Clean blue and gray color scheme'
                        },
                        {
                            name: 'Green Theme',
                            colors: {
                                primary: '#10B981',
                                secondary: '#6B7280',
                                background: '#F9FAFB',
                                text: '#111827'
                            },
                            preview: 'Professional green color scheme'
                        },
                        {
                            name: 'Purple Theme',
                            colors: {
                                primary: '#8B5CF6',
                                secondary: '#A78BFA',
                                background: '#FFFFFF',
                                text: '#111827'
                            },
                            preview: 'Creative purple color scheme'
                        },
                        {
                            name: 'Orange Theme',
                            colors: {
                                primary: '#F59E0B',
                                secondary: '#FCD34D',
                                background: '#FFFBEB',
                                text: '#111827'
                            },
                            preview: 'Energetic orange color scheme'
                        }
                    ]
                }
            };
            console.log('Using fallback designs due to AI service error');
        }
        if (!result.success) {
            console.error('AI service failed:', result.error);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: result.error || 'Failed to generate design suggestions'
            }, {
                status: 500
            });
        }
        // Extract design options from the result
        const layoutData = result.layoutData; // eslint-disable-line @typescript-eslint/no-explicit-any
        console.log('Raw layoutData from AI:', JSON.stringify(layoutData, null, 2));
        let designOptions = [];
        // Check if designOptions exist in the layoutData
        if (layoutData?.designOptions && Array.isArray(layoutData.designOptions)) {
            designOptions = layoutData.designOptions;
        } else if (layoutData?.components && Array.isArray(layoutData.components)) {
            // If we have components, create a design option from them
            designOptions = [
                {
                    id: 'generated-design-1',
                    name: 'Generated Design',
                    description: 'AI-generated design based on your requirements',
                    preview: 'Modern design with clean layout',
                    components: layoutData.components,
                    layout: layoutData.layout || {
                        type: 'dashboard',
                        theme: 'light',
                        colors: {
                            primary: '#3B82F6',
                            secondary: '#6B7280',
                            background: '#FFFFFF',
                            text: '#111827'
                        }
                    }
                }
            ];
        } else {
            // Fallback: Create multiple design options with different color schemes
            console.warn('AI response did not contain valid design options, creating fallback designs');
            designOptions = [
                {
                    id: 'fallback-design-1',
                    name: 'Modern Blue Dashboard',
                    description: 'Clean and modern design with blue color scheme',
                    preview: 'Card-based layout with blue accents',
                    components: [
                        {
                            name: 'Header',
                            type: 'header',
                            description: 'Top navigation bar',
                            properties: {
                                title: 'Dashboard',
                                showSearch: true
                            },
                            layout: {
                                x: 0,
                                y: 0,
                                width: 1200,
                                height: 80
                            }
                        },
                        {
                            name: 'Sidebar',
                            type: 'sidebar',
                            description: 'Left navigation panel',
                            properties: {
                                collapsed: false
                            },
                            layout: {
                                x: 0,
                                y: 80,
                                width: 250,
                                height: 720
                            }
                        },
                        {
                            name: 'Main Content',
                            type: 'main',
                            description: 'Main content area',
                            properties: {
                                scrollable: true
                            },
                            layout: {
                                x: 250,
                                y: 80,
                                width: 950,
                                height: 720
                            }
                        }
                    ],
                    layout: {
                        type: 'dashboard',
                        theme: 'light',
                        colors: {
                            primary: '#3B82F6',
                            secondary: '#6B7280',
                            background: '#FFFFFF',
                            text: '#111827'
                        }
                    }
                },
                {
                    id: 'fallback-design-2',
                    name: 'Green Professional',
                    description: 'Professional design with green color scheme',
                    preview: 'Clean layout with green accents',
                    components: [
                        {
                            name: 'Header',
                            type: 'header',
                            description: 'Top navigation bar',
                            properties: {
                                title: 'Dashboard',
                                showSearch: true
                            },
                            layout: {
                                x: 0,
                                y: 0,
                                width: 1200,
                                height: 80
                            }
                        },
                        {
                            name: 'Main Content',
                            type: 'main',
                            description: 'Main content area',
                            properties: {
                                scrollable: true
                            },
                            layout: {
                                x: 0,
                                y: 80,
                                width: 1200,
                                height: 720
                            }
                        }
                    ],
                    layout: {
                        type: 'professional',
                        theme: 'light',
                        colors: {
                            primary: '#10B981',
                            secondary: '#6B7280',
                            background: '#F9FAFB',
                            text: '#111827'
                        }
                    }
                },
                {
                    id: 'fallback-design-3',
                    name: 'Purple Creative',
                    description: 'Creative design with purple color scheme',
                    preview: 'Modern layout with purple accents',
                    components: [
                        {
                            name: 'Header',
                            type: 'header',
                            description: 'Top navigation bar',
                            properties: {
                                title: 'Dashboard',
                                showSearch: true
                            },
                            layout: {
                                x: 0,
                                y: 0,
                                width: 1200,
                                height: 80
                            }
                        },
                        {
                            name: 'Sidebar',
                            type: 'sidebar',
                            description: 'Left navigation panel',
                            properties: {
                                collapsed: false
                            },
                            layout: {
                                x: 0,
                                y: 80,
                                width: 200,
                                height: 720
                            }
                        },
                        {
                            name: 'Main Content',
                            type: 'main',
                            description: 'Main content area',
                            properties: {
                                scrollable: true
                            },
                            layout: {
                                x: 200,
                                y: 80,
                                width: 1000,
                                height: 720
                            }
                        }
                    ],
                    layout: {
                        type: 'creative',
                        theme: 'light',
                        colors: {
                            primary: '#8B5CF6',
                            secondary: '#A78BFA',
                            background: '#FFFFFF',
                            text: '#111827'
                        }
                    }
                },
                {
                    id: 'fallback-design-4',
                    name: 'Orange Energetic',
                    description: 'Energetic design with orange color scheme',
                    preview: 'Dynamic layout with orange accents',
                    components: [
                        {
                            name: 'Header',
                            type: 'header',
                            description: 'Top navigation bar',
                            properties: {
                                title: 'Dashboard',
                                showSearch: true
                            },
                            layout: {
                                x: 0,
                                y: 0,
                                width: 1200,
                                height: 80
                            }
                        },
                        {
                            name: 'Main Content',
                            type: 'main',
                            description: 'Main content area',
                            properties: {
                                scrollable: true
                            },
                            layout: {
                                x: 0,
                                y: 80,
                                width: 1200,
                                height: 720
                            }
                        }
                    ],
                    layout: {
                        type: 'energetic',
                        theme: 'light',
                        colors: {
                            primary: '#F59E0B',
                            secondary: '#FCD34D',
                            background: '#FFFBEB',
                            text: '#111827'
                        }
                    }
                }
            ];
        }
        // Generate images for each design option using the AI service
        console.log('🖼️ [DESIGN API] Generating images for', designOptions.length, 'design options...');
        const designOptionsWithImages = await Promise.all(designOptions.map(async (design, index)=>{
            try {
                // Create a specific prompt for this design
                const imagePrompt = `${enhancedPrompt} - ${design.name}: ${design.description}. Style: ${design.layout?.theme || 'modern'}, Colors: ${JSON.stringify(design.layout?.colors || {})}`;
                console.log(`🎨 [DESIGN API] Generating image ${index + 1}/${designOptions.length} for design: ${design.name}`);
                console.log(`📝 [DESIGN API] Image prompt: ${imagePrompt.substring(0, 100)}...`);
                // Use the AI service for image generation (will use OpenAI if hybrid service)
                const imageResult = await aiService.generateImage(imagePrompt);
                if (imageResult.success && imageResult.layoutData) {
                    console.log(`✅ [DESIGN API] Image generated successfully for: ${design.name}`);
                    return {
                        ...design,
                        image: imageResult.layoutData.image || imageResult.layoutData,
                        imagePrompt: imagePrompt
                    };
                } else {
                    console.warn(`⚠️ [DESIGN API] Failed to generate image for design: ${design.name} - ${imageResult.error}`);
                    return design;
                }
            } catch (error) {
                console.error(`❌ [DESIGN API] Error generating image for design ${design.name}:`, error);
                return design;
            }
        }));
        const processingTime = Date.now() - startTime;
        console.log('✅ [DESIGN API] Design generation completed successfully in', processingTime, 'ms');
        console.log('📊 [DESIGN API] Generated', designOptionsWithImages.length, 'design options with images');
        console.log('🎨 [DESIGN API] Color combinations available:', layoutData?.colorCombinations?.length || 0);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: {
                designOptions: designOptionsWithImages,
                dataAnalysis: layoutData?.dataAnalysis || dataAnalysis,
                colorCombinations: layoutData?.colorCombinations || []
            },
            message: 'Design suggestions with images generated successfully'
        });
    } catch (error) {
        const processingTime = Date.now() - startTime;
        console.error('❌ [DESIGN API] Design generation error after', processingTime, 'ms:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Internal server error'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__9877a55f._.js.map