module.exports = [
"[project]/.next-internal/server/app/api/figma/create/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/utils/figma.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FigmaAPI",
    ()=>FigmaAPI,
    "convertFigmaToLayoutData",
    ()=>convertFigmaToLayoutData,
    "extractFileIdFromUrl",
    ()=>extractFileIdFromUrl,
    "generateFigmaUrl",
    ()=>generateFigmaUrl,
    "isValidFigmaFileId",
    ()=>isValidFigmaFileId
]);
const FIGMA_API_BASE = 'https://api.figma.com/v1';
class FigmaAPI {
    apiKey;
    constructor(apiKey){
        this.apiKey = apiKey;
    }
    async request(endpoint, options = {}) {
        try {
            const response = await fetch(`${FIGMA_API_BASE}${endpoint}`, {
                ...options,
                headers: {
                    'X-Figma-Token': this.apiKey,
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });
            if (!response.ok) {
                throw new Error(`Figma API error: ${response.status} ${response.statusText}`);
            }
            const data = await response.json();
            return {
                success: true,
                data
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    async getFile(fileId) {
        return this.request(`/files/${fileId}`);
    }
    async getFileNodes(fileId, nodeIds) {
        const ids = nodeIds.join(',');
        return this.request(`/files/${fileId}/nodes?ids=${ids}`);
    }
    async createFile(name, _description) {
        // Note: Figma API doesn't support creating files via REST API
        // This is a mock implementation that would need to use Figma Plugin API
        // For now, we'll return a mock response with a generated file ID
        const mockFileId = this.generateMockFileId();
        return {
            success: true,
            data: {
                key: mockFileId,
                name,
                lastModified: new Date().toISOString(),
                version: '1.0.0',
                document: {
                    children: []
                },
                styles: {}
            }
        };
    }
    generateMockFileId() {
        // Generate a mock 22-character file ID similar to real Figma file IDs
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for(let i = 0; i < 22; i++){
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }
    async createFrame(fileId, parentId, frameData) {
        // Mock implementation - Figma REST API doesn't support creating nodes
        // In a real implementation, this would use Figma Plugin API
        return {
            success: true,
            data: {
                id: `mock-${Date.now()}`,
                name: frameData.name || 'Frame',
                type: 'FRAME'
            }
        };
    }
    async createNodesFromLayoutData(fileId, layoutData) {
        // Mock implementation for creating nodes from layout data
        // In a real implementation, this would use Figma Plugin API to create actual nodes
        const createdNodes = [];
        try {
            // Create main frame
            const mainFrame = layoutData.frames[0];
            if (mainFrame) {
                const frameResult = await this.createFrame(fileId, '0:0', {
                    name: mainFrame.name,
                    x: mainFrame.x,
                    y: mainFrame.y,
                    width: mainFrame.width,
                    height: mainFrame.height,
                    backgroundColor: mainFrame.backgroundColor
                });
                if (frameResult.success && frameResult.data) {
                    createdNodes.push(frameResult.data.id);
                }
            }
            return {
                success: true,
                data: {
                    createdNodes
                }
            };
        } catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Failed to create nodes'
            };
        }
    }
    async updateNode(fileId, nodeId, updates) {
        return this.request(`/files/${fileId}/nodes/${nodeId}`, {
            method: 'PATCH',
            body: JSON.stringify(updates)
        });
    }
    async getImage(fileId, nodeIds, format = 'png') {
        const ids = nodeIds.join(',');
        return this.request(`/images/${fileId}?ids=${ids}&format=${format}`);
    }
    async getComments(fileId) {
        return this.request(`/files/${fileId}/comments`);
    }
    async getVersions(fileId) {
        return this.request(`/files/${fileId}/versions`);
    }
    async getTeamProjects(teamId) {
        return this.request(`/teams/${teamId}/projects`);
    }
    async getProjectFiles(projectId) {
        return this.request(`/projects/${projectId}/files`);
    }
}
function convertFigmaToLayoutData(figmaData) {
    const document = figmaData.document;
    return {
        id: figmaData.key,
        name: figmaData.name,
        frames: convertFrames(document.children || []),
        styles: extractStyleGuide(figmaData.styles || {}),
        metadata: {
            version: figmaData.version,
            generatedAt: new Date(),
            aiModel: 'gpt-4',
            requirements: '',
            theme: 'light'
        }
    };
}
function convertFrames(figmaNodes) {
    return figmaNodes.filter((node)=>node.type === 'FRAME' || node.type === 'COMPONENT').map((node)=>({
            id: node.id,
            name: node.name,
            type: node.type,
            x: node.absoluteBoundingBox?.x || 0,
            y: node.absoluteBoundingBox?.y || 0,
            width: node.absoluteBoundingBox?.width || 0,
            height: node.absoluteBoundingBox?.height || 0,
            backgroundColor: node.backgroundColor ? `rgba(${node.backgroundColor.r * 255}, ${node.backgroundColor.g * 255}, ${node.backgroundColor.b * 255}, ${node.backgroundColor.a})` : undefined,
            children: convertNodes(node.children || []),
            constraints: {
                horizontal: node.constraints?.horizontal || 'MIN',
                vertical: node.constraints?.vertical || 'MIN'
            }
        }));
}
function convertNodes(figmaNodes) {
    return figmaNodes.map((node)=>({
            id: node.id,
            name: node.name,
            type: node.type,
            x: node.absoluteBoundingBox?.x || 0,
            y: node.absoluteBoundingBox?.y || 0,
            width: node.absoluteBoundingBox?.width || 0,
            height: node.absoluteBoundingBox?.height || 0,
            visible: node.visible !== false,
            locked: node.locked || false,
            children: node.children ? convertNodes(node.children) : undefined,
            style: extractNodeStyle(node),
            constraints: {
                horizontal: node.constraints?.horizontal || 'MIN',
                vertical: node.constraints?.vertical || 'MIN'
            }
        }));
}
function extractNodeStyle(node) {
    const style = {};
    if (node.fills && node.fills.length > 0) {
        style.fill = {
            type: node.fills[0].type,
            color: node.fills[0].color ? {
                r: node.fills[0].color.r,
                g: node.fills[0].color.g,
                b: node.fills[0].color.b,
                a: node.fills[0].color.a
            } : undefined
        };
    }
    if (node.strokes && node.strokes.length > 0) {
        style.stroke = {
            type: node.strokes[0].type,
            color: node.strokes[0].color ? {
                r: node.strokes[0].color.r,
                g: node.strokes[0].color.g,
                b: node.strokes[0].color.b,
                a: node.strokes[0].color.a
            } : undefined,
            weight: node.strokeWeight || 1,
            align: node.strokeAlign || 'INSIDE'
        };
    }
    if (node.style) {
        style.textStyle = {
            fontFamily: node.style.fontFamily || 'Inter',
            fontSize: node.style.fontSize || 16,
            fontWeight: node.style.fontWeight || 400,
            lineHeight: node.style.lineHeightPx || 24,
            letterSpacing: node.style.letterSpacing || 0,
            textAlign: node.style.textAlignHorizontal || 'LEFT',
            textDecoration: 'NONE',
            textCase: 'ORIGINAL'
        };
    }
    return Object.keys(style).length > 0 ? style : undefined;
}
function extractStyleGuide(_styles) {
    return {
        colors: [],
        typography: [],
        spacing: [],
        borderRadius: [],
        shadows: []
    };
}
function generateFigmaUrl(fileId, nodeId) {
    const baseUrl = `https://www.figma.com/file/${fileId}`;
    return nodeId ? `${baseUrl}?node-id=${nodeId}` : baseUrl;
}
function extractFileIdFromUrl(url) {
    const match = url.match(/figma\.com\/file\/([a-zA-Z0-9]+)/);
    return match ? match[1] : null;
}
function isValidFigmaFileId(fileId) {
    return /^[a-zA-Z0-9]{22}$/.test(fileId);
}
}),
"[project]/src/app/api/figma/create/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$figma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/figma.ts [app-route] (ecmascript)");
;
;
async function POST(request) {
    try {
        const { layoutData, name, description } = await request.json();
        if (!layoutData) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Layout data is required'
            }, {
                status: 400
            });
        }
        // Initialize Figma API
        const figmaAPI = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$figma$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FigmaAPI"](process.env.FIGMA_API_KEY || '');
        // Create new Figma file
        const fileResult = await figmaAPI.createFile(name || 'Laygen Generated Design', description || 'Generated by Laygen AI');
        if (!fileResult.success) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: fileResult.error
            }, {
                status: 500
            });
        }
        const fileId = fileResult.data?.key;
        if (!fileId) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                error: 'Failed to create Figma file'
            }, {
                status: 500
            });
        }
        // Create actual Figma nodes based on layoutData
        const nodesResult = await figmaAPI.createNodesFromLayoutData(fileId, layoutData);
        if (!nodesResult.success) {
            console.warn('Failed to create Figma nodes:', nodesResult.error);
        // Continue anyway as the file was created successfully
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: {
                fileId,
                name: fileResult.data?.name,
                url: `https://www.figma.com/file/${fileId}`,
                lastModified: new Date().toISOString()
            },
            message: 'Figma file created successfully'
        });
    } catch (error) {
        console.error('Figma create error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Internal server error'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__3bbeb8af._.js.map