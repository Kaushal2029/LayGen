module.exports=[88947,(e,t,r)=>{t.exports=e.x("stream",()=>require("stream"))},27699,(e,t,r)=>{t.exports=e.x("events",()=>require("events"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},20635,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/action-async-storage.external.js",()=>require("next/dist/server/app-render/action-async-storage.external.js"))},24361,(e,t,r)=>{t.exports=e.x("util",()=>require("util"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},61724,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-route-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-route-turbo.runtime.prod.js"))},73570,(e,t,r)=>{},56287,e=>{"use strict";e.s(["handler",()=>b,"patchFetch",()=>A,"routeModule",()=>y,"serverHooks",()=>C,"workAsyncStorage",()=>E,"workUnitAsyncStorage",()=>T],56287);var t=e.i(47909),r=e.i(74017),n=e.i(96250),a=e.i(59756),s=e.i(61916),o=e.i(69741),i=e.i(16795),l=e.i(87718),d=e.i(95169),u=e.i(47587),p=e.i(66012),c=e.i(70101),h=e.i(26937),x=e.i(10372),f=e.i(93695);e.i(52474);var m=e.i(220);e.s(["GET",()=>w],91556);var g=e.i(89171),v=e.i(69411);async function w(){console.log("🧪 [TEST DOWNLOAD] Testing download functionality...");try{let e=new v.default;e.file("test.html",`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Page</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Test Download</h1>
    <p>This is a test file to verify ZIP download functionality.</p>
    <script src="script.js"></script>
</body>
</html>
    `),e.file("styles.css",`
body {
    font-family: Arial, sans-serif;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f5f5f5;
}

h1 {
    color: #333;
    text-align: center;
}

p {
    color: #666;
    line-height: 1.6;
}
    `),e.file("script.js",`
console.log('Test download working!');
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page loaded successfully');
});
    `),e.file("README.md",`
# Test Download

This is a test ZIP file to verify the download functionality.

## Files included:
- test.html - Main HTML file
- styles.css - CSS styles
- script.js - JavaScript functionality
- README.md - This file

## How to test:
1. Download this ZIP file
2. Extract it
3. Open test.html in your browser
4. Check the console for messages
    `);let t=await e.generateAsync({type:"nodebuffer"});return console.log("✅ [TEST DOWNLOAD] Test ZIP created successfully, size:",t.length,"bytes"),new g.NextResponse(t,{headers:{"Content-Type":"application/zip","Content-Disposition":'attachment; filename="test-download.zip"',"Content-Length":t.length.toString()}})}catch(e){return console.error("❌ [TEST DOWNLOAD] Test failed:",e),g.NextResponse.json({success:!1,error:`Test failed: ${e instanceof Error?e.message:"Unknown error"}`},{status:500})}}var R=e.i(91556);let y=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/test-download/route",pathname:"/api/test-download",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/test-download/route.ts",nextConfigOutput:"",userland:R}),{workAsyncStorage:E,workUnitAsyncStorage:T,serverHooks:C}=y;function A(){return(0,n.patchFetch)({workAsyncStorage:E,workUnitAsyncStorage:T})}async function b(e,t,n){var g;let v="/api/test-download/route";v=v.replace(/\/index$/,"")||"/";let w=await y.prepare(e,t,{srcPage:v,multiZoneDraftMode:!1});if(!w)return t.statusCode=400,t.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:R,params:E,nextConfig:T,isDraftMode:C,prerenderManifest:A,routerServerContext:b,isOnDemandRevalidate:O,revalidateOnlyGenerated:P,resolvedPathname:N}=w,k=(0,o.normalizeAppPath)(v),D=!!(A.dynamicRoutes[k]||A.routes[N]);if(D&&!C){let e=!!A.routes[N],t=A.dynamicRoutes[k];if(t&&!1===t.fallback&&!e)throw new f.NoFallbackError}let j=null;!D||y.isDev||C||(j="/index"===(j=N)?"/":j);let q=!0===y.isDev||!D,S=D&&!q,_=e.method||"GET",H=(0,s.getTracer)(),M=H.getActiveScopeSpan(),I={params:E,prerenderManifest:A,renderOpts:{experimental:{cacheComponents:!!T.experimental.cacheComponents,authInterrupts:!!T.experimental.authInterrupts},supportsDynamicResponse:q,incrementalCache:(0,a.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:null==(g=T.experimental)?void 0:g.cacheLife,isRevalidate:S,waitUntil:n.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,n)=>y.onRequestError(e,t,n,b)},sharedContext:{buildId:R}},U=new i.NodeNextRequest(e),L=new i.NodeNextResponse(t),F=l.NextRequestAdapter.fromNodeNextRequest(U,(0,l.signalFromNodeResponse)(t));try{let o=async r=>y.handle(F,I).finally(()=>{if(!r)return;r.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let n=H.getRootSpanAttributes();if(!n)return;if(n.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${n.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=n.get("next.route");if(a){let e=`${_} ${a}`;r.setAttributes({"next.route":a,"http.route":a,"next.span_name":e}),r.updateName(e)}else r.updateName(`${_} ${e.url}`)}),i=async s=>{var i,l;let d=async({previousCacheEntry:r})=>{try{if(!(0,a.getRequestMeta)(e,"minimalMode")&&O&&P&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let i=await o(s);e.fetchMetrics=I.renderOpts.fetchMetrics;let l=I.renderOpts.pendingWaitUntil;l&&n.waitUntil&&(n.waitUntil(l),l=void 0);let d=I.renderOpts.collectedTags;if(!D)return await (0,p.sendResponse)(U,L,i,I.renderOpts.pendingWaitUntil),null;{let e=await i.blob(),t=(0,c.toNodeOutgoingHttpHeaders)(i.headers);d&&(t[x.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==I.renderOpts.collectedRevalidate&&!(I.renderOpts.collectedRevalidate>=x.INFINITE_CACHE)&&I.renderOpts.collectedRevalidate,n=void 0===I.renderOpts.collectedExpire||I.renderOpts.collectedExpire>=x.INFINITE_CACHE?void 0:I.renderOpts.collectedExpire;return{value:{kind:m.CachedRouteKind.APP_ROUTE,status:i.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:n}}}}catch(t){throw(null==r?void 0:r.isStale)&&await y.onRequestError(e,t,{routerKind:"App Router",routePath:v,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isRevalidate:S,isOnDemandRevalidate:O})},b),t}},f=await y.handleResponse({req:e,nextConfig:T,cacheKey:j,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:A,isRoutePPREnabled:!1,isOnDemandRevalidate:O,revalidateOnlyGenerated:P,responseGenerator:d,waitUntil:n.waitUntil});if(!D)return null;if((null==f||null==(i=f.value)?void 0:i.kind)!==m.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==f||null==(l=f.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,a.getRequestMeta)(e,"minimalMode")||t.setHeader("x-nextjs-cache",O?"REVALIDATED":f.isMiss?"MISS":f.isStale?"STALE":"HIT"),C&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let g=(0,c.fromNodeOutgoingHttpHeaders)(f.value.headers);return(0,a.getRequestMeta)(e,"minimalMode")&&D||g.delete(x.NEXT_CACHE_TAGS_HEADER),!f.cacheControl||t.getHeader("Cache-Control")||g.get("Cache-Control")||g.set("Cache-Control",(0,h.getCacheControlHeader)(f.cacheControl)),await (0,p.sendResponse)(U,L,new Response(f.value.body,{headers:g,status:f.value.status||200})),null};M?await i(M):await H.withPropagatedContext(e.headers,()=>H.trace(d.BaseServerSpan.handleRequest,{spanName:`${_} ${e.url}`,kind:s.SpanKind.SERVER,attributes:{"http.method":_,"http.target":e.url}},i))}catch(t){if(M||t instanceof f.NoFallbackError||await y.onRequestError(e,t,{routerKind:"App Router",routePath:k,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isRevalidate:S,isOnDemandRevalidate:O})}),D)throw t;return await (0,p.sendResponse)(U,L,new Response(null,{status:500})),null}}}];

//# sourceMappingURL=%5Broot-of-the-server%5D__61fc9c0a._.js.map