module.exports = [
"[project]/.next-internal/server/app/api/test-deepai-code/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/utils/deepai-ai.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DeepAIService",
    ()=>DeepAIService
]);
class DeepAIService {
    apiKey;
    constructor(apiKey){
        this.apiKey = apiKey;
    }
    async parseDocument(document) {
        console.log('📄 [DEEPAI] Starting document parsing...');
        console.log('📄 [DEEPAI] Document type:', document.type);
        try {
            const response = await fetch('https://api.deepai.org/api/text-generator', {
                method: 'POST',
                headers: {
                    'Api-Key': this.apiKey,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    text: `Analyze this ${document.type} document and extract structured data for web application development. Document content: ${document.content}`
                })
            });
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`DeepAI API error: ${response.status} - ${errorText}`);
            }
            const data = await response.json();
            console.log('✅ [DEEPAI] Document parsed successfully');
            // Parse the response and create structured data
            const parsedData = this.parseAIResponse(data.output || '');
            return {
                success: true,
                layoutData: parsedData,
                confidence: 0.8
            };
        } catch (error) {
            console.error('❌ [DEEPAI] Document parsing failed:', error);
            return {
                success: false,
                error: error.message || 'DeepAI document parsing failed',
                confidence: 0
            };
        }
    }
    async generateCode(layoutData, framework = 'html') {
        console.log('💻 [DEEPAI] Starting code generation...');
        console.log('💻 [DEEPAI] Framework:', framework);
        try {
            const selectedColors = layoutData.selectedColors || {}; // eslint-disable-line @typescript-eslint/no-explicit-any
            const description = layoutData.dataAnalysis?.description || 'A modern web application'; // eslint-disable-line @typescript-eslint/no-explicit-any
            const prompt = `${description}

Use these colors: ${JSON.stringify(selectedColors)}

Return ONLY valid JSON with this EXACT structure:
{
  "html": "complete HTML content for index.html",
  "css": "complete CSS content for styles.css", 
  "javascript": "complete JavaScript content for script.js",
  "readme": "complete README content explaining the application"
}`;
            const response = await fetch('https://api.deepai.org/api/text-generator', {
                method: 'POST',
                headers: {
                    'Api-Key': this.apiKey,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    text: prompt
                })
            });
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`DeepAI API error: ${response.status} - ${errorText}`);
            }
            const data = await response.json();
            console.log('✅ [DEEPAI] Code generated successfully');
            // Parse the JSON response
            const codeData = JSON.parse(data.output || '{}');
            return {
                success: true,
                layoutData: codeData,
                confidence: 0.8
            };
        } catch (error) {
            console.error('❌ [DEEPAI] Code generation failed:', error);
            return {
                success: false,
                error: error.message || 'DeepAI code generation failed',
                confidence: 0
            };
        }
    }
    parseAIResponse(response) {
        try {
            // Try to parse as JSON first
            return JSON.parse(response);
        } catch  {
            // If not JSON, create a basic structure
            return {
                dataAnalysis: {
                    projectName: 'Generated Project',
                    description: response.substring(0, 200) + '...',
                    appType: 'Web Application',
                    dataType: 'Mixed Content'
                },
                layout: {
                    theme: 'modern',
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#6B7280',
                        background: '#FFFFFF',
                        text: '#111827'
                    }
                }
            };
        }
    }
    async generateImage(prompt) {
        console.log('🎨 [DEEPAI] Starting image generation...');
        console.log('📝 [DEEPAI] Prompt:', prompt.substring(0, 100) + '...');
        try {
            const response = await fetch('https://api.deepai.org/api/text2img', {
                method: 'POST',
                headers: {
                    'Api-Key': this.apiKey,
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    text: prompt,
                    width: '1024',
                    height: '768'
                })
            });
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`DeepAI API error: ${response.status} - ${errorText}`);
            }
            const data = await response.json();
            console.log('✅ [DEEPAI] Image generated successfully');
            console.log('🖼️ [DEEPAI] Response:', data);
            if (data.output_url) {
                return {
                    success: true,
                    layoutData: {
                        image: data.output_url
                    },
                    confidence: 0.8
                };
            } else {
                throw new Error('DeepAI returned an unexpected response format');
            }
        } catch (error) {
            console.error('❌ [DEEPAI] DeepAI image generation failed:', error);
            return {
                success: false,
                error: `DeepAI image generation failed: ${error.message || error}`,
                confidence: 0
            };
        }
    }
}
}),
"[project]/src/lib/config.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Configuration for Laygen application
__turbopack_context__.s([
    "config",
    ()=>config,
    "getEnvVar",
    ()=>getEnvVar,
    "isDevelopment",
    ()=>isDevelopment,
    "isProduction",
    ()=>isProduction,
    "validateConfig",
    ()=>validateConfig
]);
const config = {
    // API Keys (set these in your environment variables)
    ai: {
        provider: 'gemini',
        apiKey: process.env.GEMINI_API_KEY || '',
        model: 'gemini-1.5-flash',
        fallbackProvider: 'openai',
        fallbackApiKey: process.env.OPENAI_API_KEY || '',
        fallbackModel: 'gpt-3.5-turbo'
    },
    // Replicate AI for image generation
    replicate: {
        apiKey: process.env.REPLICATE_API_TOKEN || '',
        defaultModel: 'stability-ai/stable-diffusion:db21e45d3f7023abc2a46e38a211633768e4ea5badbff3d474b0a0b3a1866d9',
        imageGeneration: {
            width: 1024,
            height: 768,
            numInferenceSteps: 20,
            guidanceScale: 7.5,
            numOutputs: 1
        }
    },
    // DeepAI for image generation
    deepai: {
        apiKey: process.env.DEEPAI_API_KEY || '',
        imageGeneration: {
            width: 1024,
            height: 768
        }
    },
    app: {
        url: ("TURBOPACK compile-time value", "http://localhost:3000") || 'http://localhost:3000',
        name: 'Laygen',
        description: 'From Requirements to Ready UI — Instantly'
    },
    // File upload limits
    upload: {
        maxFileSize: 10 * 1024 * 1024,
        allowedTypes: [
            'text/plain',
            'text/markdown',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ],
        allowedExtensions: [
            '.txt',
            '.md',
            '.pdf',
            '.doc',
            '.docx'
        ]
    },
    // Code generation settings
    codeGeneration: {
        defaultFramework: 'nextjs',
        includeTypeScript: true,
        includeTailwindCSS: true,
        includeResponsiveDesign: true
    }
};
function validateConfig() {
    const errors = [];
    if (!config.ai.apiKey) {
        errors.push('GEMINI_API_KEY is required');
    }
    if (config.ai.fallbackProvider === 'openai' && !config.ai.fallbackApiKey) {
        errors.push('OPENAI_API_KEY is required as fallback');
    }
    if (!config.replicate.apiKey) {
        errors.push('REPLICATE_API_TOKEN is required for image generation');
    }
    if (!config.deepai.apiKey) {
        errors.push('DEEPAI_API_KEY is required for image generation');
    }
    return {
        valid: errors.length === 0,
        errors
    };
}
function getEnvVar(key, fallback = '') {
    return process.env[key] || fallback;
}
const isDevelopment = ("TURBOPACK compile-time value", "development") === 'development';
const isProduction = ("TURBOPACK compile-time value", "development") === 'production';
}),
"[project]/src/app/api/test-deepai-code/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$deepai$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/deepai-ai.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/config.ts [app-route] (ecmascript)");
;
;
;
async function POST(request) {
    console.log('🧪 [TEST DEEPAI CODE] Testing DeepAI code generation...');
    const startTime = Date.now();
    try {
        const { layoutData, testScenario } = await request.json();
        console.log('📋 [TEST DEEPAI CODE] Test scenario:', testScenario);
        console.log('📋 [TEST DEEPAI CODE] Layout data keys:', Object.keys(layoutData || {}));
        // Check if DeepAI API key is available
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].deepai.apiKey) {
            console.log('❌ [TEST DEEPAI CODE] DeepAI API key not configured');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: 'DeepAI API key not configured',
                error: 'DEEPAI_API_KEY is required for this test',
                isDeepAIGenerated: false
            }, {
                status: 400
            });
        }
        console.log('🤖 [TEST DEEPAI CODE] Creating DeepAI service...');
        const deepaiService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$deepai$2d$ai$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DeepAIService"](__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].deepai.apiKey);
        console.log('🧠 [TEST DEEPAI CODE] Calling DeepAI generateCode...');
        const result = await deepaiService.generateCode(layoutData, 'html');
        const processingTime = Date.now() - startTime;
        console.log(`⏱️ [TEST DEEPAI CODE] Processing time: ${processingTime}ms`);
        console.log('📊 [TEST DEEPAI CODE] DeepAI result:', {
            success: result.success,
            hasLayoutData: !!result.layoutData,
            error: result.error,
            confidence: result.confidence
        });
        if (result.success) {
            console.log('✅ [TEST DEEPAI CODE] DeepAI code generation successful!');
            // Validate the generated code structure
            const codeData = result.layoutData; // eslint-disable-line @typescript-eslint/no-explicit-any
            const validation = {
                hasHtml: !!codeData.html,
                hasCss: !!codeData.css,
                hasJavascript: !!codeData.javascript,
                hasReadme: !!codeData.readme,
                htmlLength: codeData.html?.length || 0,
                cssLength: codeData.css?.length || 0,
                jsLength: codeData.javascript?.length || 0,
                readmeLength: codeData.readme?.length || 0
            };
            console.log('📊 [TEST DEEPAI CODE] Code validation:', validation);
            // Check if the code is usable
            const isUsable = validation.hasHtml && validation.hasCss && validation.htmlLength > 100 && validation.cssLength > 50;
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                message: 'DeepAI code generation successful',
                data: codeData,
                isDeepAIGenerated: true,
                validation,
                isUsable,
                processingTime,
                testScenario,
                aiProvider: 'DeepAI'
            });
        } else {
            console.log('❌ [TEST DEEPAI CODE] DeepAI code generation failed:', result.error);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: false,
                message: 'DeepAI code generation failed',
                error: result.error,
                isDeepAIGenerated: false,
                processingTime,
                testScenario,
                aiProvider: 'DeepAI'
            }, {
                status: 500
            });
        }
    } catch (error) {
        const processingTime = Date.now() - startTime;
        console.error('❌ [TEST DEEPAI CODE] Error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            message: 'DeepAI test failed',
            error: error instanceof Error ? error.message : 'Unknown error',
            isDeepAIGenerated: false,
            processingTime,
            aiProvider: 'DeepAI'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__70f6bd6a._.js.map