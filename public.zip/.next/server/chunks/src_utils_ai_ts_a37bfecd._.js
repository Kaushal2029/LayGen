module.exports=[93811,e=>{"use strict";e.s(["createAIService",()=>ea,"parseDocumentContent",()=>er,"validateDocument",()=>eo],93811);var t,n,a,s,r,i,o,l,c,d,u,p,g=e.i(65617);!function(e){e.STRING="string",e.NUMBER="number",e.INTEGER="integer",e.BOOLEAN="boolean",e.ARRAY="array",e.OBJECT="object"}(t||(t={})),function(e){e.LANGUAGE_UNSPECIFIED="language_unspecified",e.PYTHON="python"}(n||(n={})),function(e){e.OUTCOME_UNSPECIFIED="outcome_unspecified",e.OUTCOME_OK="outcome_ok",e.OUTCOME_FAILED="outcome_failed",e.OUTCOME_DEADLINE_EXCEEDED="outcome_deadline_exceeded"}(a||(a={}));let h=["user","model","function","system"];!function(e){e.HARM_CATEGORY_UNSPECIFIED="HARM_CATEGORY_UNSPECIFIED",e.HARM_CATEGORY_HATE_SPEECH="HARM_CATEGORY_HATE_SPEECH",e.HARM_CATEGORY_SEXUALLY_EXPLICIT="HARM_CATEGORY_SEXUALLY_EXPLICIT",e.HARM_CATEGORY_HARASSMENT="HARM_CATEGORY_HARASSMENT",e.HARM_CATEGORY_DANGEROUS_CONTENT="HARM_CATEGORY_DANGEROUS_CONTENT",e.HARM_CATEGORY_CIVIC_INTEGRITY="HARM_CATEGORY_CIVIC_INTEGRITY"}(s||(s={})),function(e){e.HARM_BLOCK_THRESHOLD_UNSPECIFIED="HARM_BLOCK_THRESHOLD_UNSPECIFIED",e.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",e.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",e.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",e.BLOCK_NONE="BLOCK_NONE"}(r||(r={})),function(e){e.HARM_PROBABILITY_UNSPECIFIED="HARM_PROBABILITY_UNSPECIFIED",e.NEGLIGIBLE="NEGLIGIBLE",e.LOW="LOW",e.MEDIUM="MEDIUM",e.HIGH="HIGH"}(i||(i={})),function(e){e.BLOCKED_REASON_UNSPECIFIED="BLOCKED_REASON_UNSPECIFIED",e.SAFETY="SAFETY",e.OTHER="OTHER"}(o||(o={})),function(e){e.FINISH_REASON_UNSPECIFIED="FINISH_REASON_UNSPECIFIED",e.STOP="STOP",e.MAX_TOKENS="MAX_TOKENS",e.SAFETY="SAFETY",e.RECITATION="RECITATION",e.LANGUAGE="LANGUAGE",e.BLOCKLIST="BLOCKLIST",e.PROHIBITED_CONTENT="PROHIBITED_CONTENT",e.SPII="SPII",e.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",e.OTHER="OTHER"}(l||(l={})),function(e){e.TASK_TYPE_UNSPECIFIED="TASK_TYPE_UNSPECIFIED",e.RETRIEVAL_QUERY="RETRIEVAL_QUERY",e.RETRIEVAL_DOCUMENT="RETRIEVAL_DOCUMENT",e.SEMANTIC_SIMILARITY="SEMANTIC_SIMILARITY",e.CLASSIFICATION="CLASSIFICATION",e.CLUSTERING="CLUSTERING"}(c||(c={})),function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.AUTO="AUTO",e.ANY="ANY",e.NONE="NONE"}(d||(d={})),function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.MODE_DYNAMIC="MODE_DYNAMIC"}(u||(u={}));class m extends Error{constructor(e){super(`[GoogleGenerativeAI Error]: ${e}`)}}class f extends m{constructor(e,t){super(e),this.response=t}}class y extends m{constructor(e,t,n,a){super(e),this.status=t,this.statusText=n,this.errorDetails=a}}class E extends m{}class I extends m{}!function(e){e.GENERATE_CONTENT="generateContent",e.STREAM_GENERATE_CONTENT="streamGenerateContent",e.COUNT_TOKENS="countTokens",e.EMBED_CONTENT="embedContent",e.BATCH_EMBED_CONTENTS="batchEmbedContents"}(p||(p={}));class w{constructor(e,t,n,a,s){this.model=e,this.task=t,this.apiKey=n,this.stream=a,this.requestOptions=s}toString(){var e,t;let n=(null==(e=this.requestOptions)?void 0:e.apiVersion)||"v1beta",a=(null==(t=this.requestOptions)?void 0:t.baseUrl)||"https://generativelanguage.googleapis.com",s=`${a}/${n}/${this.model}:${this.task}`;return this.stream&&(s+="?alt=sse"),s}}async function C(e){var t;let n=new Headers;n.append("Content-Type","application/json"),n.append("x-goog-api-client",function(e){let t=[];return(null==e?void 0:e.apiClient)&&t.push(e.apiClient),t.push("genai-js/0.24.1"),t.join(" ")}(e.requestOptions)),n.append("x-goog-api-key",e.apiKey);let a=null==(t=e.requestOptions)?void 0:t.customHeaders;if(a){if(!(a instanceof Headers))try{a=new Headers(a)}catch(e){throw new E(`unable to convert customHeaders value ${JSON.stringify(a)} to Headers: ${e.message}`)}for(let[e,t]of a.entries()){if("x-goog-api-key"===e)throw new E(`Cannot set reserved header name ${e}`);if("x-goog-api-client"===e)throw new E(`Header name ${e} can only be set using the apiClient field`);n.append(e,t)}}return n}async function v(e,t,n,a,s,r){let i=new w(e,t,n,a,r);return{url:i.toString(),fetchOptions:Object.assign(Object.assign({},function(e){let t={};if((null==e?void 0:e.signal)!==void 0||(null==e?void 0:e.timeout)>=0){let n=new AbortController;(null==e?void 0:e.timeout)>=0&&setTimeout(()=>n.abort(),e.timeout),(null==e?void 0:e.signal)&&e.signal.addEventListener("abort",()=>{n.abort()}),t.signal=n.signal}return t}(r)),{method:"POST",headers:await C(i),body:s})}}async function b(e,t,n,a,s,r={},i=fetch){let{url:o,fetchOptions:l}=await v(e,t,n,a,s,r);return S(o,l,i)}async function S(e,t,n=fetch){let a;try{a=await n(e,t)}catch(n){var s=n,r=e;let t=s;throw"AbortError"===t.name?(t=new I(`Request aborted when fetching ${r.toString()}: ${s.message}`)).stack=s.stack:s instanceof y||s instanceof E||((t=new m(`Error fetching from ${r.toString()}: ${s.message}`)).stack=s.stack),t}return a.ok||await O(a,e),a}async function O(e,t){let n,a="";try{let t=await e.json();a=t.error.message,t.error.details&&(a+=` ${JSON.stringify(t.error.details)}`,n=t.error.details)}catch(e){}throw new y(`Error fetching from ${t.toString()}: [${e.status} ${e.statusText}] ${a}`,e.status,e.statusText,n)}function A(e){return e.text=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning text from the first candidate only. Access response.candidates directly to use the other candidates.`),x(e.candidates[0]))throw new f(`${R(e)}`,e);return function(e){var t,n,a,s;let r=[];if(null==(n=null==(t=e.candidates)?void 0:t[0].content)?void 0:n.parts)for(let t of null==(s=null==(a=e.candidates)?void 0:a[0].content)?void 0:s.parts)t.text&&r.push(t.text),t.executableCode&&r.push("\n```"+t.executableCode.language+"\n"+t.executableCode.code+"\n```\n"),t.codeExecutionResult&&r.push("\n```\n"+t.codeExecutionResult.output+"\n```\n");return r.length>0?r.join(""):""}(e)}if(e.promptFeedback)throw new f(`Text not available. ${R(e)}`,e);return""},e.functionCall=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),x(e.candidates[0]))throw new f(`${R(e)}`,e);return console.warn("response.functionCall() is deprecated. Use response.functionCalls() instead."),N(e)[0]}if(e.promptFeedback)throw new f(`Function call not available. ${R(e)}`,e)},e.functionCalls=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),x(e.candidates[0]))throw new f(`${R(e)}`,e);return N(e)}if(e.promptFeedback)throw new f(`Function call not available. ${R(e)}`,e)},e}function N(e){var t,n,a,s;let r=[];if(null==(n=null==(t=e.candidates)?void 0:t[0].content)?void 0:n.parts)for(let t of null==(s=null==(a=e.candidates)?void 0:a[0].content)?void 0:s.parts)t.functionCall&&r.push(t.functionCall);return r.length>0?r:void 0}let T=[l.RECITATION,l.SAFETY,l.LANGUAGE];function x(e){return!!e.finishReason&&T.includes(e.finishReason)}function R(e){var t,n,a;let s="";if((!e.candidates||0===e.candidates.length)&&e.promptFeedback)s+="Response was blocked",(null==(t=e.promptFeedback)?void 0:t.blockReason)&&(s+=` due to ${e.promptFeedback.blockReason}`),(null==(n=e.promptFeedback)?void 0:n.blockReasonMessage)&&(s+=`: ${e.promptFeedback.blockReasonMessage}`);else if(null==(a=e.candidates)?void 0:a[0]){let t=e.candidates[0];x(t)&&(s+=`Candidate was blocked due to ${t.finishReason}`,t.finishMessage&&(s+=`: ${t.finishMessage}`))}return s}function _(e){return this instanceof _?(this.v=e,this):new _(e)}"function"==typeof SuppressedError&&SuppressedError;let M=/^data\: (.*)(?:\n\n|\r\r|\r\n\r\n)/;async function $(e){let t=[],n=e.getReader();for(;;){let{done:e,value:a}=await n.read();if(e)return A(function(e){let t=e[e.length-1],n={promptFeedback:null==t?void 0:t.promptFeedback};for(let t of e){if(t.candidates){let e=0;for(let a of t.candidates)if(n.candidates||(n.candidates=[]),n.candidates[e]||(n.candidates[e]={index:e}),n.candidates[e].citationMetadata=a.citationMetadata,n.candidates[e].groundingMetadata=a.groundingMetadata,n.candidates[e].finishReason=a.finishReason,n.candidates[e].finishMessage=a.finishMessage,n.candidates[e].safetyRatings=a.safetyRatings,a.content&&a.content.parts){n.candidates[e].content||(n.candidates[e].content={role:a.content.role||"user",parts:[]});let t={};for(let s of a.content.parts)s.text&&(t.text=s.text),s.functionCall&&(t.functionCall=s.functionCall),s.executableCode&&(t.executableCode=s.executableCode),s.codeExecutionResult&&(t.codeExecutionResult=s.codeExecutionResult),0===Object.keys(t).length&&(t.text=""),n.candidates[e].content.parts.push(t)}e++}t.usageMetadata&&(n.usageMetadata=t.usageMetadata)}return n}(t));t.push(a)}}async function D(e,t,n,a){let[s,r]=(function(e){let t=e.getReader();return new ReadableStream({start(e){let n="";return function a(){return t.read().then(({value:t,done:s})=>{let r;if(s)return n.trim()?void e.error(new m("Failed to parse stream")):void e.close();let i=(n+=t).match(M);for(;i;){try{r=JSON.parse(i[1])}catch(t){e.error(new m(`Error parsing JSON response: "${i[1]}"`));return}e.enqueue(r),i=(n=n.substring(i[0].length)).match(M)}return a()}).catch(e=>{let t=e;throw t.stack=e.stack,t="AbortError"===t.name?new I("Request aborted when reading from the stream"):new m("Error reading from the stream")})}()}})})((await b(t,p.STREAM_GENERATE_CONTENT,e,!0,JSON.stringify(n),a)).body.pipeThrough(new TextDecoderStream("utf8",{fatal:!0}))).tee();return{stream:function(e){return function(e,t,n){if(!Symbol.asyncIterator)throw TypeError("Symbol.asyncIterator is not defined.");var a,s=n.apply(e,t||[]),r=[];return a={},i("next"),i("throw"),i("return"),a[Symbol.asyncIterator]=function(){return this},a;function i(e){s[e]&&(a[e]=function(t){return new Promise(function(n,a){r.push([e,t,n,a])>1||o(e,t)})})}function o(e,t){try{var n;(n=s[e](t)).value instanceof _?Promise.resolve(n.value.v).then(l,c):d(r[0][2],n)}catch(e){d(r[0][3],e)}}function l(e){o("next",e)}function c(e){o("throw",e)}function d(e,t){e(t),r.shift(),r.length&&o(r[0][0],r[0][1])}}(this,arguments,function*(){let t=e.getReader();for(;;){let{value:e,done:n}=yield _(t.read());if(n)break;yield yield _(A(e))}})}(s),response:$(r)}}async function F(e,t,n,a){let s=await b(t,p.GENERATE_CONTENT,e,!1,JSON.stringify(n),a);return{response:A(await s.json())}}function G(e){if(null!=e){if("string"==typeof e)return{role:"system",parts:[{text:e}]};if(e.text)return{role:"system",parts:[e]};if(e.parts)if(!e.role)return{role:"system",parts:e.parts};else return e}}function P(e){let t=[];if("string"==typeof e)t=[{text:e}];else for(let n of e)"string"==typeof n?t.push({text:n}):t.push(n);var n=t;let a={role:"user",parts:[]},s={role:"function",parts:[]},r=!1,i=!1;for(let e of n)"functionResponse"in e?(s.parts.push(e),i=!0):(a.parts.push(e),r=!0);if(r&&i)throw new m("Within a single message, FunctionResponse cannot be mixed with other type of part in the request for sending chat message.");if(!r&&!i)throw new m("No content is provided for sending chat message.");return r?a:s}function k(e){let t;return t=e.contents?e:{contents:[P(e)]},e.systemInstruction&&(t.systemInstruction=G(e.systemInstruction)),t}let L=["text","inlineData","functionCall","functionResponse","executableCode","codeExecutionResult"],U={user:["text","inlineData"],function:["functionResponse"],model:["text","functionCall","executableCode","codeExecutionResult"],system:["text"]};function j(e){var t;if(void 0===e.candidates||0===e.candidates.length)return!1;let n=null==(t=e.candidates[0])?void 0:t.content;if(void 0===n||void 0===n.parts||0===n.parts.length)return!1;for(let e of n.parts)if(void 0===e||0===Object.keys(e).length||void 0!==e.text&&""===e.text)return!1;return!0}let B="SILENT_ERROR";class H{constructor(e,t,n,a={}){this.model=t,this.params=n,this._requestOptions=a,this._history=[],this._sendPromise=Promise.resolve(),this._apiKey=e,(null==n?void 0:n.history)&&(!function(e){let t=!1;for(let n of e){let{role:e,parts:a}=n;if(!t&&"user"!==e)throw new m(`First content should be with role 'user', got ${e}`);if(!h.includes(e))throw new m(`Each item should include role field. Got ${e} but valid roles are: ${JSON.stringify(h)}`);if(!Array.isArray(a))throw new m("Content should have 'parts' property with an array of Parts");if(0===a.length)throw new m("Each Content should have at least one part");let s={text:0,inlineData:0,functionCall:0,functionResponse:0,fileData:0,executableCode:0,codeExecutionResult:0};for(let e of a)for(let t of L)t in e&&(s[t]+=1);let r=U[e];for(let t of L)if(!r.includes(t)&&s[t]>0)throw new m(`Content with role '${e}' can't contain '${t}' part`);t=!0}}(n.history),this._history=n.history)}async getHistory(){return await this._sendPromise,this._history}async sendMessage(e,t={}){var n,a,s,r,i,o;let l;await this._sendPromise;let c=P(e),d={safetySettings:null==(n=this.params)?void 0:n.safetySettings,generationConfig:null==(a=this.params)?void 0:a.generationConfig,tools:null==(s=this.params)?void 0:s.tools,toolConfig:null==(r=this.params)?void 0:r.toolConfig,systemInstruction:null==(i=this.params)?void 0:i.systemInstruction,cachedContent:null==(o=this.params)?void 0:o.cachedContent,contents:[...this._history,c]},u=Object.assign(Object.assign({},this._requestOptions),t);return this._sendPromise=this._sendPromise.then(()=>F(this._apiKey,this.model,d,u)).then(e=>{var t;if(j(e.response)){this._history.push(c);let n=Object.assign({parts:[],role:"model"},null==(t=e.response.candidates)?void 0:t[0].content);this._history.push(n)}else{let t=R(e.response);t&&console.warn(`sendMessage() was unsuccessful. ${t}. Inspect response object for details.`)}l=e}).catch(e=>{throw this._sendPromise=Promise.resolve(),e}),await this._sendPromise,l}async sendMessageStream(e,t={}){var n,a,s,r,i,o;await this._sendPromise;let l=P(e),c={safetySettings:null==(n=this.params)?void 0:n.safetySettings,generationConfig:null==(a=this.params)?void 0:a.generationConfig,tools:null==(s=this.params)?void 0:s.tools,toolConfig:null==(r=this.params)?void 0:r.toolConfig,systemInstruction:null==(i=this.params)?void 0:i.systemInstruction,cachedContent:null==(o=this.params)?void 0:o.cachedContent,contents:[...this._history,l]},d=Object.assign(Object.assign({},this._requestOptions),t),u=D(this._apiKey,this.model,c,d);return this._sendPromise=this._sendPromise.then(()=>u).catch(e=>{throw Error(B)}).then(e=>e.response).then(e=>{if(j(e)){this._history.push(l);let t=Object.assign({},e.candidates[0].content);t.role||(t.role="model"),this._history.push(t)}else{let t=R(e);t&&console.warn(`sendMessageStream() was unsuccessful. ${t}. Inspect response object for details.`)}}).catch(e=>{e.message!==B&&console.error(e)}),u}}async function J(e,t,n,a){return(await b(t,p.COUNT_TOKENS,e,!1,JSON.stringify(n),a)).json()}async function K(e,t,n,a){return(await b(t,p.EMBED_CONTENT,e,!1,JSON.stringify(n),a)).json()}async function Y(e,t,n,a){let s=n.requests.map(e=>Object.assign(Object.assign({},e),{model:t}));return(await b(t,p.BATCH_EMBED_CONTENTS,e,!1,JSON.stringify({requests:s}),a)).json()}class q{constructor(e,t,n={}){this.apiKey=e,this._requestOptions=n,t.model.includes("/")?this.model=t.model:this.model=`models/${t.model}`,this.generationConfig=t.generationConfig||{},this.safetySettings=t.safetySettings||[],this.tools=t.tools,this.toolConfig=t.toolConfig,this.systemInstruction=G(t.systemInstruction),this.cachedContent=t.cachedContent}async generateContent(e,t={}){var n;let a=k(e),s=Object.assign(Object.assign({},this._requestOptions),t);return F(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:null==(n=this.cachedContent)?void 0:n.name},a),s)}async generateContentStream(e,t={}){var n;let a=k(e),s=Object.assign(Object.assign({},this._requestOptions),t);return D(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:null==(n=this.cachedContent)?void 0:n.name},a),s)}startChat(e){var t;return new H(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:null==(t=this.cachedContent)?void 0:t.name},e),this._requestOptions)}async countTokens(e,t={}){let n=function(e,t){var n;let a={model:null==t?void 0:t.model,generationConfig:null==t?void 0:t.generationConfig,safetySettings:null==t?void 0:t.safetySettings,tools:null==t?void 0:t.tools,toolConfig:null==t?void 0:t.toolConfig,systemInstruction:null==t?void 0:t.systemInstruction,cachedContent:null==(n=null==t?void 0:t.cachedContent)?void 0:n.name,contents:[]},s=null!=e.generateContentRequest;if(e.contents){if(s)throw new E("CountTokensRequest must have one of contents or generateContentRequest, not both.");a.contents=e.contents}else if(s)a=Object.assign(Object.assign({},a),e.generateContentRequest);else{let t=P(e);a.contents=[t]}return{generateContentRequest:a}}(e,{model:this.model,generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:this.cachedContent}),a=Object.assign(Object.assign({},this._requestOptions),t);return J(this.apiKey,this.model,n,a)}async embedContent(e,t={}){let n="string"==typeof e||Array.isArray(e)?{content:P(e)}:e,a=Object.assign(Object.assign({},this._requestOptions),t);return K(this.apiKey,this.model,n,a)}async batchEmbedContents(e,t={}){let n=Object.assign(Object.assign({},this._requestOptions),t);return Y(this.apiKey,this.model,e,n)}}class z{constructor(e){this.apiKey=e}getGenerativeModel(e,t){if(!e.model)throw new m("Must provide a model name. Example: genai.getGenerativeModel({ model: 'my-model-name' })");return new q(this.apiKey,e,t)}getGenerativeModelFromCachedContent(e,t,n){if(!e.name)throw new E("Cached content must contain a `name` field.");if(!e.model)throw new E("Cached content must contain a `model` field.");for(let n of["model","systemInstruction"])if((null==t?void 0:t[n])&&e[n]&&(null==t?void 0:t[n])!==e[n]){if("model"===n&&(t.model.startsWith("models/")?t.model.replace("models/",""):t.model)===(e.model.startsWith("models/")?e.model.replace("models/",""):e.model))continue;throw new E(`Different value for "${n}" specified in modelParams (${t[n]}) and cachedContent (${e[n]})`)}let a=Object.assign(Object.assign({},t),{model:e.model,tools:e.tools,toolConfig:e.toolConfig,systemInstruction:e.systemInstruction,cachedContent:e});return new q(this.apiKey,a,n)}}class V{genAI;model;constructor(e){this.genAI=new z(e),this.model=this.genAI.getGenerativeModel({model:"gemini-1.5-flash"})}async parseDocument(e){try{let t,n,a=!1;try{let t=JSON.parse(e.content);a="excel_data"===t.type}catch{}if(a){let n=JSON.parse(e.content);t=`
          Create a web application based on this Excel file description. The user wants to build a data management application.
          
          File Information:
          - File Name: ${n.fileName}
          - File Size: ${n.fileSize} bytes
          - File Type: ${n.fileType}
          
          Generate a complete application design with the following structure:
          {
            "dataAnalysis": {
              "dataType": "Data Management Application",
              "columns": ["Title", "Description", "Type", "Priority", "Status"],
              "recordCount": "Multiple records",
              "dataPatterns": "Structured data with title, description, type, priority, and status fields",
              "suggestedAppType": "Task/Project Management Dashboard",
              "projectName": "${n.fileName.replace(/\.(xlsx|xls)$/i,"")}",
              "titleColumn": "Title"
            },
            "designOptions": [
              {
                "id": "dashboard_1",
                "name": "Modern Dashboard",
                "description": "Clean dashboard with cards and filters",
                "preview": "Modern card-based layout with search and filter options",
                "components": [
                  {
                    "name": "Header",
                    "type": "header",
                    "description": "Application header with title and search",
                    "properties": {
                      "title": "Project Management",
                      "showSearch": true
                    },
                    "layout": {
                      "x": 0,
                      "y": 0,
                      "width": 1200,
                      "height": 80
                    }
                  },
                  {
                    "name": "FilterBar",
                    "type": "filter",
                    "description": "Filter controls for type and priority",
                    "properties": {
                      "filters": ["Type", "Priority", "Status"]
                    },
                    "layout": {
                      "x": 0,
                      "y": 80,
                      "width": 1200,
                      "height": 60
                    }
                  },
                  {
                    "name": "DataGrid",
                    "type": "table",
                    "description": "Main data display table",
                    "properties": {
                      "columns": ["Title", "Description", "Type", "Priority", "Status", "Actions"],
                      "sortable": true,
                      "editable": true
                    },
                    "layout": {
                      "x": 0,
                      "y": 140,
                      "width": 1200,
                      "height": 400
                    }
                  }
                ],
                "layout": {
                  "type": "dashboard",
                  "theme": "light",
                  "colors": {
                    "primary": "#3B82F6",
                    "secondary": "#6B7280",
                    "background": "#FFFFFF",
                    "text": "#111827"
                  }
                }
              },
              {
                "id": "card_2",
                "name": "Card Layout",
                "description": "Card-based layout for better visual appeal",
                "preview": "Grid of cards showing each data item",
                "components": [
                  {
                    "name": "CardGrid",
                    "type": "grid",
                    "description": "Grid of data cards",
                    "properties": {
                      "columns": 3,
                      "cardType": "data"
                    },
                    "layout": {
                      "x": 0,
                      "y": 0,
                      "width": 1200,
                      "height": 600
                    }
                  }
                ],
                "layout": {
                  "type": "grid",
                  "theme": "light",
                  "colors": {
                    "primary": "#10B981",
                    "secondary": "#6B7280",
                    "background": "#F9FAFB",
                    "text": "#111827"
                  }
                }
              }
            ],
            "requirements": "Create a responsive web application for managing structured data with CRUD operations, filtering, and search functionality"
          }
        `}else t=`
          Analyze the following document and extract design requirements. 
          Return a JSON object with the following structure:
          {
            "components": [
              {
                "name": "Component Name",
                "type": "button|input|card|header|footer|etc",
                "description": "What this component does",
                "properties": {
                  "text": "Button text",
                  "color": "primary|secondary|etc",
                  "size": "small|medium|large",
                  "position": "top|center|bottom|left|right"
                },
                "layout": {
                  "x": 0,
                  "y": 0,
                  "width": 200,
                  "height": 50
                }
              }
            ],
            "layout": {
              "type": "single-page|multi-page|dashboard|landing",
              "theme": "light|dark|auto",
              "colors": {
                "primary": "#3B82F6",
                "secondary": "#6B7280",
                "background": "#FFFFFF",
                "text": "#111827"
              },
              "typography": {
                "heading": "Inter Bold",
                "body": "Inter Regular",
                "sizes": {
                  "h1": 32,
                  "h2": 24,
                  "h3": 20,
                  "body": 16,
                  "small": 14
                }
              },
              "spacing": {
                "xs": 4,
                "sm": 8,
                "md": 16,
                "lg": 24,
                "xl": 32
              }
            },
            "requirements": "Summary of key requirements"
          }

          Document content:
          ${e.content}
        `;let s=`You are a design system expert. Analyze documents and extract structured design requirements. Always return valid JSON.

${t}`,r=await this.model.generateContent(s),i=(await r.response).text();if(!i)throw Error("No response from Gemini");let o=i.trim();if(o.includes("```json")){let e=o.match(/```json\s*([\s\S]*?)\s*```/);e&&(o=e[1].trim())}else if(o.includes("```")){let e=o.match(/```\s*([\s\S]*?)\s*```/);e&&(o=e[1].trim())}let l=o.indexOf("{"),c=o.lastIndexOf("}");-1!==l&&-1!==c&&c>l&&(o=o.substring(l,c+1)),o=o.replace(/\/\/.*$/gm,"").replace(/\/\*[\s\S]*?\*\//g,"").replace(/,(\s*[}\]])/g,"$1").replace(/([{,]\s*)(\w+):/g,'$1"$2":').replace(/:\s*'([^']*)'/g,': "$1"').replace(/:\s*([^",{\[\s][^,}\]]*?)(\s*[,}])/g,(e,t,n)=>{let a=t.trim();return/^[\d\-\.]+$/.test(a)||/^(true|false|null)$/.test(a)||a.startsWith('"')?e:`: "${a}"${n}`}).replace(/"\s*:\s*"([^"]*)"\s*"/g,'": "$1"').replace(/\s+/g," ").trim(),console.log("Cleaned JSON content:",o.substring(0,500)+"...");try{n=JSON.parse(o)}catch(e){console.error("❌ [GEMINI] JSON parse error:",e),console.error("Problematic JSON:",o);try{o=o.replace(/\/\/.*$/gm,"").replace(/\/\*[\s\S]*?\*\//g,"").replace(/([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:/g,'$1"$2":').replace(/:\s*([^",{\[\s][^,}\]]*?)(\s*[,}])/g,(e,t,n)=>{let a=t.trim();return/^[\d\-\.]+$/.test(a)||/^(true|false|null)$/.test(a)||a.startsWith('"')?e:`: "${a}"${n}`}).replace(/,(\s*[}\]])/g,"$1").replace(/([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:/g,'$1"$2":').replace(/:\s*"([^"]*)"\s*([,}])/g,': "$1"$2').replace(/\s+/g," ").trim(),console.log("Retry with cleaned JSON:",o.substring(0,500)+"..."),n=JSON.parse(o)}catch(e){console.error("Second JSON parse error:",e),console.error("Problematic JSON at position 374:",o.substring(350,400));try{let e=o.match(/"designOptions"\s*:\s*\[([\s\S]*?)\](?=\s*[,}])/);if(e){let t=e[1];t=t.replace(/\/\/.*$/gm,"").replace(/\/\*[\s\S]*?\*\//g,"").replace(/,(\s*[}\]])/g,"$1").replace(/([{,]\s*)(\w+):/g,'$1"$2":').replace(/:\s*'([^']*)'/g,': "$1"').replace(/:\s*([^",{\[\s][^,}\]]*?)(\s*[,}])/g,(e,t,n)=>{let a=t.trim();return/^[\d\-\.]+$/.test(a)||/^(true|false|null)$/.test(a)||a.startsWith('"')?e:`: "${a}"${n}`}).replace(/\s+/g," ").trim();let a=`{"designOptions": [${t}]}`;console.log("Extracting designOptions only:",a.substring(0,200)+"..."),n=JSON.parse(a)}else throw Error("Could not extract designOptions from malformed JSON")}catch(e){console.error("Final JSON parse error:",e),n={designOptions:[{id:"fallback-1",name:"Modern Design",description:"Clean and modern interface",preview:"Responsive layout with modern components",components:[{name:"Header",type:"header",description:"Top navigation",properties:{title:"App"},layout:{x:0,y:0,width:1200,height:80}}],layout:{type:"dashboard",theme:"light",colors:{primary:"#3B82F6",secondary:"#6B7280",background:"#FFFFFF",text:"#111827"}}}]},console.log("Using fallback design due to JSON parsing failure")}}}if(n.designOptions&&Array.isArray(n.designOptions))return{success:!0,layoutData:n,confidence:.85,suggestions:["Consider adding hover states for interactive elements","Ensure proper contrast ratios for accessibility","Add responsive breakpoints for mobile devices"]};let d=this.convertToLayoutData(n);return{success:!0,layoutData:d,confidence:.85,suggestions:["Consider adding hover states for interactive elements","Ensure proper contrast ratios for accessibility","Add responsive breakpoints for mobile devices"]}}catch(e){return{success:!1,error:e instanceof Error?e.message:"Failed to parse document",confidence:0}}}async generateLayoutVariations(e,t=2){try{let n=`
        Based on this existing layout, generate ${t} alternative variations that maintain the same functionality but with different visual arrangements.
        
        Current layout:
        ${JSON.stringify(e,null,2)}
        
        Return a JSON array with ${t} layout variations, each following the same structure as the input layout.
        Focus on:
        - Different component arrangements
        - Alternative color schemes
        - Varied spacing and sizing
        - Different visual hierarchy
        - Maintain accessibility and usability
      `,a=`You are a UI/UX designer. Generate creative layout variations while maintaining functionality and usability. Always return valid JSON arrays.

${n}`,s=await this.model.generateContent(a),r=(await s.response).text();if(!r)throw Error("No response from Gemini");let i=r.trim();if(i.includes("```json")){let e=i.match(/```json\s*([\s\S]*?)\s*```/);e&&(i=e[1].trim())}else if(i.includes("```")){let e=i.match(/```\s*([\s\S]*?)\s*```/);e&&(i=e[1].trim())}let o=i.indexOf("["),l=i.lastIndexOf("]");-1!==o&&-1!==l&&l>o&&(i=i.substring(o,l+1));let c=JSON.parse(i);return{success:!0,layoutData:c[0],confidence:.8,suggestions:["Try different color combinations","Experiment with component positioning","Consider alternative typography scales"]}}catch(e){return{success:!1,error:e instanceof Error?e.message:"Failed to generate variations",confidence:0}}}async generateImage(e){try{return console.log("Generating image with Gemini with prompt:",e.substring(0,100)+"..."),{success:!1,error:"Image generation is not available with Gemini. Please use OpenAI for image generation.",confidence:0}}catch(e){return console.error("Image generation error:",e),{success:!1,error:e instanceof Error?e.message:"Failed to generate image",confidence:0}}}async generateCode(e,t="html"){for(let t=1;t<=5;t++)try{let n;console.log(`🔄 [GEMINI] Code generation attempt ${t}/5`),console.log(`⏰ [GEMINI] Attempt started at: ${new Date().toISOString()}`);let a=e.dataAnalysis?.projectName||"Generated App",s=e.selectedColors||{},r=e.dataAnalysis?.description||"A modern web application",i=`You are an expert full-stack developer. Create a COMPLETE, PRODUCTION-READY web application for: ${a}

Project Description: ${r}

REQUIREMENTS:
1. HTML: Create a comprehensive HTML page with modern structure, semantic elements, forms, navigation, and interactive components
2. CSS: Write modern, responsive CSS with advanced styling, animations, transitions, and mobile-first design
3. JavaScript: Build complete functionality with data management, user interactions, form handling, dynamic content, and modern ES6+ features
4. Colors: Use these colors: ${JSON.stringify(s)}
5. Features: Include search, filtering, CRUD operations, data validation, error handling, loading states, and user feedback
6. Responsive: Mobile-first design that works perfectly on all screen sizes
7. Modern: Use latest web standards, CSS Grid/Flexbox, smooth animations, and professional UI/UX
8. Professional: Clean, well-structured code with proper comments and error handling

APPLICATION STRUCTURE:
- Modern header with navigation and branding
- Main content area with data visualization and management
- Interactive forms for adding/editing data
- Advanced search and filter functionality
- Data tables with sorting and pagination
- Modal dialogs and popups for interactions
- Footer with additional information
- Responsive sidebar navigation
- Loading states and smooth animations
- Comprehensive error handling and user feedback
- Data persistence and state management

Make it a REAL, COMPLETE, PRODUCTION-READY application with substantial functionality and modern design patterns.

Return ONLY valid JSON with this EXACT structure:
{
  "html": "complete HTML content for index.html",
  "css": "complete CSS content for styles.css", 
  "javascript": "complete JavaScript content for script.js",
  "readme": "complete README content explaining the application purpose and usage"
}`,o=`You are an expert full-stack developer with extensive experience. Create COMPLETE, PRODUCTION-READY web applications with comprehensive functionality and modern design.

REQUIREMENTS:
- Generate FULL, functional applications with substantial code
- Create comprehensive HTML with modern structure and semantic elements
- Write advanced CSS with responsive design, animations, and modern styling
- Build complete JavaScript with data management, interactions, and modern features
- Include detailed README with clear instructions

QUALITY STANDARDS:
- Professional, clean, well-structured code
- Modern web standards and best practices
- Responsive design that works on all devices
- Comprehensive functionality and user experience
- Proper error handling and validation

You MUST return ONLY valid JSON in the exact format specified. No markdown, no explanations, no code blocks.`,l=`${o}

${i}`;console.log(`📝 [GEMINI] Sending prompt to Gemini API (attempt ${t})...`);let c=await this.model.generateContent(l),d=(await c.response).text();if(!d)throw Error("No response from Gemini");console.log(`📥 [GEMINI] Received response from Gemini (${d.length} characters)`);let u=d.trim();if(console.log(`🔍 [GEMINI] Raw response content (first 500 chars):`,u.substring(0,500)),u.includes("```json")){let e=u.match(/```json\s*([\s\S]*?)\s*```/);e&&(u=e[1].trim(),console.log(`📝 [GEMINI] Extracted JSON from markdown block`))}else if(u.includes("```")){let e=u.match(/```\s*([\s\S]*?)\s*```/);e&&(u=e[1].trim(),console.log(`📝 [GEMINI] Extracted content from code block`))}let p=u.indexOf("{"),g=u.lastIndexOf("}");-1!==p&&-1!==g&&g>p&&(u=u.substring(p,g+1),console.log(`📝 [GEMINI] Extracted JSON object (${u.length} chars)`)),console.log(`🔍 [GEMINI] Final JSON content (first 200 chars):`,u.substring(0,200));try{n=JSON.parse(u),console.log(`✅ [GEMINI] JSON parsed successfully`)}catch(r){console.error(`❌ [GEMINI] JSON parse error:`,r),console.log(`🔍 [GEMINI] Problematic JSON content:`,u),console.log(`🔄 [GEMINI] Attempting regex extraction as fallback...`);let e=u.match(/"html"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/),t=u.match(/"css"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/),a=u.match(/"javascript"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/),s=u.match(/"readme"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/);if(e||t||a||s)console.log(`✅ [GEMINI] Regex extraction successful`),n={html:e?e[1].replace(/\\n/g,"\n").replace(/\\"/g,'"'):"",css:t?t[1].replace(/\\n/g,"\n").replace(/\\"/g,'"'):"",javascript:a?a[1].replace(/\\n/g,"\n").replace(/\\"/g,'"'):"",readme:s?s[1].replace(/\\n/g,"\n").replace(/\\"/g,'"'):""};else throw r}let h=n.html?.length||0,m=n.css?.length||0,f=n.javascript?.length||0,y=n.readme?.length||0;if(console.log(`📊 [GEMINI] Content validation:`,{htmlLength:h,cssLength:m,jsLength:f,readmeLength:y}),0===h||0===m||0===f)throw Error("Generated content is empty - missing HTML, CSS, or JavaScript");return console.log("✅ [GEMINI] Code generation successful on attempt",t),console.log("🎉 [GEMINI] AI-generated code received successfully!"),console.log("📊 [GEMINI] Generated code structure:",Object.keys(n)),console.log("📊 [GEMINI] Content lengths:",{html:n.html?.length||0,css:n.css?.length||0,javascript:n.javascript?.length||0,readme:n.readme?.length||0}),{success:!0,layoutData:{html:n.html,css:n.css,javascript:n.javascript,readme:n.readme},confidence:.9,suggestions:["Add proper error handling","Implement loading states","Add data validation","Consider performance optimizations"]}}catch(e){if(console.error(`❌ [GEMINI] Code generation attempt ${t} failed:`,e),console.error(`🔍 [GEMINI] Error details:`,{message:e.message,code:e.code,status:e.status,attempt:t,maxRetries:5}),(e.message?.includes("503")||e.message?.includes("overloaded")||e.message?.includes("Service Unavailable")||e.message?.includes("429")||e.message?.includes("rate limit")||e.message?.includes("quota")||e.message?.includes("timeout"))&&t<5){let n=3e3*t;console.log(`⏳ [GEMINI] Retrying in ${n}ms... (attempt ${t+1}/5)`),console.log(`🔄 [GEMINI] Retry reason: ${e.message}`),await new Promise(e=>setTimeout(e,n));continue}if(5===t)return console.error("❌ [GEMINI] All code generation attempts failed"),console.log("🔍 [GEMINI] Final error details:",{message:e.message,code:e.code,status:e.status,attempts:5}),{success:!1,error:`AI code generation failed after 5 attempts: ${e.message||"Unknown error"}`,confidence:0}}return{success:!1,error:"Code generation failed unexpectedly",confidence:0}}convertToLayoutData(e){let t=e.components?.map((t,n)=>({id:`frame-${n}`,name:t.name,type:"FRAME",x:t.layout?.x||0,y:t.layout?.y||0,width:t.layout?.width||200,height:t.layout?.height||50,backgroundColor:e.layout?.colors?.background||"#FFFFFF",children:[],constraints:{horizontal:"MIN",vertical:"MIN"}}))||[];return{id:`layout-${Date.now()}`,name:"Generated Layout",frames:t,styles:{colors:Object.entries(e.layout?.colors||{}).map(([e,t])=>({name:e,value:this.hexToRgba(t),description:`${e} color`})),typography:[],spacing:Object.entries(e.layout?.spacing||{}).map(([e,t])=>({name:e,value:t,description:`${e} spacing`})),borderRadius:[],shadows:[]},metadata:{version:"1.0.0",generatedAt:new Date,aiModel:"gemini-1.5-flash",requirements:e.requirements||"",theme:e.layout?.theme||"light"}}}hexToRgba(e){let t=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);return t?{r:parseInt(t[1],16)/255,g:parseInt(t[2],16)/255,b:parseInt(t[3],16)/255,a:1}:{r:0,g:0,b:0,a:1}}}var W=e.i(76465);class X{apiKey;constructor(e){this.apiKey=e}async generateImage(e){console.log("🎨 [DEEPAI] Starting image generation..."),console.log("📝 [DEEPAI] Prompt:",e.substring(0,100)+"...");try{let t=await fetch("https://api.deepai.org/api/text2img",{method:"POST",headers:{"Api-Key":this.apiKey,"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({text:e,width:"1024",height:"768"})});if(!t.ok){let e=await t.text();throw Error(`DeepAI API error: ${t.status} - ${e}`)}let n=await t.json();if(console.log("✅ [DEEPAI] Image generated successfully"),console.log("🖼️ [DEEPAI] Response:",n),n.output_url)return{success:!0,layoutData:{image:n.output_url},message:"Image generated successfully by DeepAI"};throw Error("DeepAI returned an unexpected response format")}catch(e){return console.error("❌ [DEEPAI] DeepAI image generation failed:",e),{success:!1,error:`DeepAI image generation failed: ${e.message||e}`,layoutData:null}}}}var Q=e.i(98003);class Z{geminiService;deepaiService;constructor(e,t){this.geminiService=new V(e),this.deepaiService=new X(t)}async parseDocument(e){return this.geminiService.parseDocument(e)}async generateLayoutVariations(e){return this.geminiService.generateLayoutVariations(e)}async generateCode(e,t="nextjs"){return this.geminiService.generateCode(e,t)}async generateImage(e){return this.deepaiService.generateImage(e)}}class ee{geminiService;replicateService;constructor(e,t){this.geminiService=new V(e),this.replicateService=new W.ReplicateAIService(t)}async parseDocument(e){return this.geminiService.parseDocument(e)}async generateLayoutVariations(e){return this.geminiService.generateLayoutVariations(e)}async generateCode(e,t="nextjs"){return this.geminiService.generateCode(e,t)}async generateImage(e){return this.replicateService.generateImage(e)}}class et{geminiService;openaiService;constructor(e,t){this.geminiService=new V(e),this.openaiService=new es(t)}async parseDocument(e){return this.geminiService.parseDocument(e)}async generateLayoutVariations(e){return this.geminiService.generateLayoutVariations(e)}async generateCode(e,t="nextjs"){return this.geminiService.generateCode(e,t)}async generateImage(e){return this.openaiService.generateImage(e)}}class en{primaryService;fallbackService;serviceName;constructor(e,t,n){this.primaryService=e,this.fallbackService=t,this.serviceName=n}async parseDocument(e){try{return await this.primaryService.parseDocument(e)}catch(t){return console.log(`⚠️ [ROBUST AI] Primary service failed, trying fallback...`),await this.fallbackService.parseDocument(e)}}async generateLayoutVariations(e){try{return await this.primaryService.generateLayoutVariations(e)}catch(t){return console.log(`⚠️ [ROBUST AI] Primary service failed, trying fallback...`),await this.fallbackService.generateLayoutVariations(e)}}async generateCode(e,t="nextjs"){try{return await this.primaryService.generateCode(e,t)}catch(n){return console.log(`⚠️ [ROBUST AI] Primary service failed, trying fallback...`),await this.fallbackService.generateCode(e,t)}}async generateImage(e){try{return await this.primaryService.generateImage(e)}catch(t){return console.log(`⚠️ [ROBUST AI] Primary service failed, trying fallback...`),await this.fallbackService.generateImage(e)}}}function ea(){let e=Q.config.ai.provider,t=Q.config.ai.apiKey,n=Q.config.ai.fallbackApiKey,a=Q.config.replicate.apiKey,s=Q.config.deepai.apiKey;if("gemini"===e&&t&&s){console.log("Using DeepAI Hybrid service (Gemini for text, DeepAI for images)");let e=new Z(t,s);return n?new en(e,new et(t,n),"DeepAI Hybrid with OpenAI fallback"):e}if("gemini"===e&&t&&a){console.log("Using Hybrid AI service (Gemini for text, Replicate for images)");let e=new ee(t,a);return n?new en(e,new et(t,n),"Hybrid with OpenAI fallback"):e}if("gemini"===e&&t&&n)return console.log("Using Legacy Hybrid AI service (Gemini for text, OpenAI for images)"),new et(t,n);if("gemini"===e&&t){console.log("Using Gemini AI service (no image generation)");let e=new V(t);return n?new en(e,new es(n),"Gemini with OpenAI fallback"):e}if(t)return console.log("Using OpenAI service"),new es(t);if(n)return console.log("Falling back to OpenAI service"),new es(n);throw Error("No valid AI service configuration found")}class es{apiKey;availableModels=["gpt-3.5-turbo","gpt-4","gpt-4-turbo"];baseURL="https://api.openai.com/v1";constructor(e){this.apiKey=e}async tryModels(e,t,n){let a=[];for(let s of this.availableModels)try{console.log(`Trying model: ${s}`),console.log(`API Key present: ${!!this.apiKey}`),console.log(`API Key length: ${this.apiKey.length}`),console.log(`API Key starts with: ${this.apiKey.substring(0,10)}...`);let a=await g.default.post(`${this.baseURL}/chat/completions`,{model:s,messages:[{role:"system",content:t},{role:"user",content:e}],temperature:n.temperature,max_tokens:n.max_tokens},{headers:{Authorization:`Bearer ${this.apiKey}`,"Content-Type":"application/json"},timeout:6e4});return console.log(`Model ${s} succeeded`),console.log(`Response status: ${a.status}`),a.data}catch(r){let e=r?.response?.status;404===e?console.warn(`Model ${s} not found, skipping to next model.`):429===e?console.warn(`Model ${s} rate limited, trying next model.`):401===e?console.error(`Model ${s} unauthorized - API key issue.`):403===e&&console.error(`Model ${s} forbidden - check API key permissions.`);let t=r instanceof Error?r.message:"Unknown error",n=r?.response?`Status: ${r.response.status}, Data: ${JSON.stringify(r.response.data)}`:t;console.error(`Model ${s} failed:`,n),a.push(`${s}: ${n}`)}let s=a.some(e=>e.includes("429")||e.includes("quota")||e.includes("billing")),r=a.some(e=>e.includes("401")||e.includes("403")||e.includes("unauthorized")),i=a.some(e=>e.includes("404")||e.includes("not found")),o="Possible solutions:\n";throw r?o+="1) Check your OpenAI API key is valid and has proper permissions\n":o+="1) Check your OpenAI API key is valid\n",s?o+="2) Add payment method and credits to your OpenAI account\n":o+="2) Verify you have credits/quota available\n",i?o+="3) Check your OpenAI plan includes the requested models\n":o+="3) Check your OpenAI plan includes the models\n",o+="4) Try again in a few minutes if rate limited\n5) Visit https://platform.openai.com/account/billing to manage your account",Error(`All AI models failed. Errors:
${a.join("\n")}

${o}`)}async parseDocument(e){try{let t,n=!1;try{let t=JSON.parse(e.content);n="excel_data"===t.type}catch{}if(n){let n=JSON.parse(e.content);t=`
          Create a web application based on this Excel file description. The user wants to build a data management application.
          
          File Information:
          - File Name: ${n.fileName}
          - File Size: ${n.fileSize} bytes
          - File Type: ${n.fileType}
          
          Generate a complete application design with the following structure:
          {
            "dataAnalysis": {
              "dataType": "Data Management Application",
              "columns": ["Title", "Description", "Type", "Priority", "Status"],
              "recordCount": "Multiple records",
              "dataPatterns": "Structured data with title, description, type, priority, and status fields",
              "suggestedAppType": "Task/Project Management Dashboard",
              "projectName": "${n.fileName.replace(/\.(xlsx|xls)$/i,"")}",
              "titleColumn": "Title"
            },
            "designOptions": [
              {
                "id": "dashboard_1",
                "name": "Modern Dashboard",
                "description": "Clean dashboard with cards and filters",
                "preview": "Modern card-based layout with search and filter options",
                "components": [
                  {
                    "name": "Header",
                    "type": "header",
                    "description": "Application header with title and search",
                    "properties": {
                      "title": "Project Management",
                      "showSearch": true
                    },
                    "layout": {
                      "x": 0,
                      "y": 0,
                      "width": 1200,
                      "height": 80
                    }
                  },
                  {
                    "name": "FilterBar",
                    "type": "filter",
                    "description": "Filter controls for type and priority",
                    "properties": {
                      "filters": ["Type", "Priority", "Status"]
                    },
                    "layout": {
                      "x": 0,
                      "y": 80,
                      "width": 1200,
                      "height": 60
                    }
                  },
                  {
                    "name": "DataGrid",
                    "type": "table",
                    "description": "Main data display table",
                    "properties": {
                      "columns": ["Title", "Description", "Type", "Priority", "Status", "Actions"],
                      "sortable": true,
                      "editable": true
                    },
                    "layout": {
                      "x": 0,
                      "y": 140,
                      "width": 1200,
                      "height": 400
                    }
                  }
                ],
                "layout": {
                  "type": "dashboard",
                  "theme": "light",
                  "colors": {
                    "primary": "#3B82F6",
                    "secondary": "#6B7280",
                    "background": "#FFFFFF",
                    "text": "#111827"
                  }
                }
              },
              {
                "id": "card_2",
                "name": "Card Layout",
                "description": "Card-based layout for better visual appeal",
                "preview": "Grid of cards showing each data item",
                "components": [
                  {
                    "name": "CardGrid",
                    "type": "grid",
                    "description": "Grid of data cards",
                    "properties": {
                      "columns": 3,
                      "cardType": "data"
                    },
                    "layout": {
                      "x": 0,
                      "y": 0,
                      "width": 1200,
                      "height": 600
                    }
                  }
                ],
                "layout": {
                  "type": "grid",
                  "theme": "light",
                  "colors": {
                    "primary": "#10B981",
                    "secondary": "#6B7280",
                    "background": "#F9FAFB",
                    "text": "#111827"
                  }
                }
              }
            ],
            "requirements": "Create a responsive web application for managing structured data with CRUD operations, filtering, and search functionality"
          }
        `}else t=`
          Analyze the following document and extract design requirements. 
          Return a JSON object with the following structure:
          {
            "components": [
              {
                "name": "Component Name",
                "type": "button|input|card|header|footer|etc",
                "description": "What this component does",
                "properties": {
                  "text": "Button text",
                  "color": "primary|secondary|etc",
                  "size": "small|medium|large",
                  "position": "top|center|bottom|left|right"
                },
                "layout": {
                  "x": 0,
                  "y": 0,
                  "width": 200,
                  "height": 50
                }
              }
            ],
            "layout": {
              "type": "single-page|multi-page|dashboard|landing",
              "theme": "light|dark|auto",
              "colors": {
                "primary": "#3B82F6",
                "secondary": "#6B7280",
                "background": "#FFFFFF",
                "text": "#111827"
              },
              "typography": {
                "heading": "Inter Bold",
                "body": "Inter Regular",
                "sizes": {
                  "h1": 32,
                  "h2": 24,
                  "h3": 20,
                  "body": 16,
                  "small": 14
                }
              },
              "spacing": {
                "xs": 4,
                "sm": 8,
                "md": 16,
                "lg": 24,
                "xl": 32
              }
            },
            "requirements": "Summary of key requirements"
          }

          Document content:
          ${e.content}
        `;let a=await this.tryModels(t,"You are a design system expert. Analyze documents and extract structured design requirements. Always return valid JSON.",{temperature:.3,max_tokens:2e3}),s=a.choices[0]?.message?.content;if(!s)throw Error("No response from AI");let r=JSON.parse(s),i=this.convertToLayoutData(r);return{success:!0,layoutData:i,confidence:.85,suggestions:["Consider adding hover states for interactive elements","Ensure proper contrast ratios for accessibility","Add responsive breakpoints for mobile devices"]}}catch(e){return{success:!1,error:e instanceof Error?e.message:"Failed to parse document",confidence:0}}}async generateLayoutVariations(e,t=2){try{let n=`
        Based on this existing layout, generate ${t} alternative variations that maintain the same functionality but with different visual arrangements.
        
        Current layout:
        ${JSON.stringify(e,null,2)}
        
        Return a JSON array with ${t} layout variations, each following the same structure as the input layout.
        Focus on:
        - Different component arrangements
        - Alternative color schemes
        - Varied spacing and sizing
        - Different visual hierarchy
        - Maintain accessibility and usability
      `,a=await this.tryModels(n,"You are a UI/UX designer. Generate creative layout variations while maintaining functionality and usability. Always return valid JSON arrays.",{temperature:.7,max_tokens:3e3}),s=a.choices[0]?.message?.content;if(!s)throw Error("No response from AI");let r=JSON.parse(s);return{success:!0,layoutData:r[0],confidence:.8,suggestions:["Try different color combinations","Experiment with component positioning","Consider alternative typography scales"]}}catch(e){return{success:!1,error:e instanceof Error?e.message:"Failed to generate variations",confidence:0}}}async generateImage(e){try{console.log("Generating image with prompt:",e.substring(0,100)+"..."),console.log(`API Key present: ${!!this.apiKey}`),console.log(`API Key length: ${this.apiKey.length}`);let t=await g.default.post(`${this.baseURL}/images/generations`,{model:"dall-e-3",prompt:e,n:1,size:"1024x1024",quality:"standard",style:"natural"},{headers:{Authorization:`Bearer ${this.apiKey}`,"Content-Type":"application/json"},timeout:12e4});return console.log("Image generation response status:",t.status),console.log("Image generation response data:",t.data),{success:!0,layoutData:{imageUrl:t.data?.data?.[0]?.url||"",prompt:e},confidence:.9}}catch(e){return console.error("Image generation error:",e),{success:!1,error:e.response?`Status: ${e.response.status}, Data: ${JSON.stringify(e.response.data)}`:e instanceof Error?e.message:"Failed to generate image",confidence:0}}}async generateCode(e,t="html"){try{let n=`
        Generate a complete, working HTML, CSS, and JavaScript application based on the provided data and design requirements.
        Create a single-page application that can be run immediately by opening the HTML file in a browser.
        
        IMPORTANT: Analyze the layout data to understand:
        - What type of application this should be
        - What data fields/columns are present
        - What functionality is needed based on the data structure
        - What UI components are required
        - Use the project name and selected colors from the data
        - Generate features and functionality based on the actual data, not hardcoded assumptions
        
        Return a JSON object with this structure:
        {
          "html": {
            "index": "<!DOCTYPE html><html><head>...</head><body>...</body></html>",
            "title": "Project Name"
          },
          "css": {
            "main": "/* Complete CSS styles with your selected colors */",
            "variables": ":root { /* CSS custom properties for colors */ }"
          },
          "javascript": {
            "main": "// Complete JavaScript functionality",
            "data": "// Sample data based on your Excel structure"
          },
          "features": [
            "Add new items",
            "Edit existing items", 
            "Filter and search",
            "Delete items",
            "Responsive design"
          ],
          "instructions": "Simply open index.html in any web browser to run the application"
        }

        Layout data to analyze:
        ${JSON.stringify(e,null,2)}
      `,a=await this.tryModels(n,`You are a senior ${t} developer. Generate clean, production-ready code with proper TypeScript types, accessibility features, and responsive design. Always return valid JSON.`,{temperature:.2,max_tokens:4e3}),s=a.choices[0]?.message?.content;if(!s)throw Error("No response from AI");let r=JSON.parse(s);return{success:!0,layoutData:r,confidence:.9,suggestions:["Add proper error boundaries","Implement loading states","Add unit tests for components","Consider performance optimizations"]}}catch(e){return{success:!1,error:e instanceof Error?e.message:"Failed to generate code",confidence:0}}}convertToLayoutData(e){let t=e.components?.map((t,n)=>({id:`frame-${n}`,name:t.name,type:"FRAME",x:t.layout?.x||0,y:t.layout?.y||0,width:t.layout?.width||200,height:t.layout?.height||50,backgroundColor:e.layout?.colors?.background||"#FFFFFF",children:[],constraints:{horizontal:"MIN",vertical:"MIN"}}))||[];return{id:`layout-${Date.now()}`,name:"Generated Layout",frames:t,styles:{colors:Object.entries(e.layout?.colors||{}).map(([e,t])=>({name:e,value:this.hexToRgba(t),description:`${e} color`})),typography:[],spacing:Object.entries(e.layout?.spacing||{}).map(([e,t])=>({name:e,value:t,description:`${e} spacing`})),borderRadius:[],shadows:[]},metadata:{version:"1.0.0",generatedAt:new Date,aiModel:"gpt-4",requirements:e.requirements||"",theme:e.layout?.theme||"light"}}}hexToRgba(e){let t=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);return t?{r:parseInt(t[1],16)/255,g:parseInt(t[2],16)/255,b:parseInt(t[3],16)/255,a:1}:{r:0,g:0,b:0,a:1}}}async function er(e){return"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"===e.type||"application/vnd.ms-excel"===e.type||e.name.endsWith(".xlsx")||e.name.endsWith(".xls")?await ei(e):("text/plain"===e.type||e.name.endsWith(".txt")||"text/markdown"===e.type||e.name.endsWith(".md"),await e.text())}async function ei(e){try{return await e.arrayBuffer(),JSON.stringify({type:"excel_data",fileName:e.name,fileSize:e.size,fileType:e.type,note:"Excel file detected. AI will analyze the actual content structure and data patterns to generate appropriate design options and application type."})}catch(e){throw Error("Failed to parse Excel file: "+(e instanceof Error?e.message:"Unknown error"))}}function eo(e){let t="."+e.name.split(".").pop()?.toLowerCase();return["text/plain","text/markdown","application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-excel"].includes(e.type)||[".txt",".md",".pdf",".doc",".docx",".xlsx",".xls"].includes(t)?e.size>0xa00000?{valid:!1,error:"File size too large. Please upload files smaller than 10MB."}:{valid:!0}:{valid:!1,error:"Unsupported file type. Please upload PDF, DOC, DOCX, TXT, MD, or Excel files."}}}];

//# sourceMappingURL=src_utils_ai_ts_a37bfecd._.js.map