var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/figma/create/route.js")
R.c("server/chunks/node_modules_next_6e7afa3a._.js")
R.c("server/chunks/[root-of-the-server]__3bbeb8af._.js")
R.m("[project]/.next-internal/server/app/api/figma/create/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/figma/create/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/figma/create/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
