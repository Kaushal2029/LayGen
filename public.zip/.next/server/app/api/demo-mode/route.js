var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/demo-mode/route.js")
R.c("server/chunks/[root-of-the-server]__af46640c._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(4519)
R.m(86044)
module.exports=R.m(86044).exports
