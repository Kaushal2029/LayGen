var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-code-generation/route.js")
R.c("server/chunks/[root-of-the-server]__7e55b278._.js")
R.c("server/chunks/_ed6fdf37._.js")
R.c("server/chunks/[root-of-the-server]__df61a572._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.c("server/chunks/src_utils_ai_ts_a37bfecd._.js")
R.m(15396)
R.m(45376)
module.exports=R.m(45376).exports
