var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-download/route.js")
R.c("server/chunks/[root-of-the-server]__61fc9c0a._.js")
R.c("server/chunks/[root-of-the-server]__081dc71a._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(73570)
R.m(56287)
module.exports=R.m(56287).exports
