var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-openai/route.js")
R.c("server/chunks/[root-of-the-server]__0fa27e47._.js")
R.c("server/chunks/[root-of-the-server]__df61a572._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(20060)
R.m(85510)
module.exports=R.m(85510).exports
