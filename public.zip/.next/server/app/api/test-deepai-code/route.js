var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-deepai-code/route.js")
R.c("server/chunks/node_modules_next_bc9d29bf._.js")
R.c("server/chunks/[root-of-the-server]__70f6bd6a._.js")
R.m("[project]/.next-internal/server/app/api/test-deepai-code/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/test-deepai-code/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/test-deepai-code/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
