var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-models/route.js")
R.c("server/chunks/[root-of-the-server]__4237d493._.js")
R.c("server/chunks/[root-of-the-server]__df61a572._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.m(73516)
R.m(25730)
module.exports=R.m(25730).exports
