var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/generate-image/route.js")
R.c("server/chunks/[root-of-the-server]__c91fde29._.js")
R.c("server/chunks/_ed6fdf37._.js")
R.c("server/chunks/[root-of-the-server]__df61a572._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.c("server/chunks/src_utils_ai_ts_a37bfecd._.js")
R.m(65463)
R.m(98582)
module.exports=R.m(98582).exports
