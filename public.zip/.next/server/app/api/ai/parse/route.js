var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/parse/route.js")
R.c("server/chunks/node_modules_next_7d15b720._.js")
R.c("server/chunks/node_modules_axios_lib_965bc11c._.js")
R.c("server/chunks/node_modules_mime-db_f53cdd2e._.js")
R.c("server/chunks/node_modules_bd158696._.js")
R.c("server/chunks/[root-of-the-server]__ee26902c._.js")
R.m("[project]/.next-internal/server/app/api/ai/parse/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/ai/parse/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/ai/parse/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
