var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-replicate/route.js")
R.c("server/chunks/[root-of-the-server]__744aa530._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.c("server/chunks/_ed6fdf37._.js")
R.m(38597)
R.m(94087)
module.exports=R.m(94087).exports
