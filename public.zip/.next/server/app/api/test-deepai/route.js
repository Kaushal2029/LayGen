var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-deepai/route.js")
R.c("server/chunks/[root-of-the-server]__bccd7b93._.js")
R.c("server/chunks/_ed6fdf37._.js")
R.c("server/chunks/[root-of-the-server]__df61a572._.js")
R.c("server/chunks/node_modules_next_317e10ab._.js")
R.c("server/chunks/src_utils_ai_ts_a37bfecd._.js")
R.m(12097)
R.m(74925)
module.exports=R.m(74925).exports
